package Setup;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import java.util.jar.JarEntry;
import java.util.jar.JarOutputStream;
import java.util.jar.Manifest;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import org.apache.commons.io.FileUtils;
import org.jdom.Attribute;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.input.SAXBuilder;




/**
 * The class performs various operations based on configurations defined in settings.xml
 *
 */
public class SetUpRun {
	
	String ACF2=System.getProperty("user.home").split("\\\\")[2];
	int BUFFER_SIZE = 10240;
	
	/**
	 * The function deletes the corrupted jar from .m2\repository
	 * @param parent is a string parameter which takes name of parent folder of corrupted jar
	 * @throws Exception
	 */	
	private void deleteCorruptedJars(String parent) throws Exception
	{
		String SRC_FOLDER = System.getProperty("user.home")+"\\.m2\\repository\\"+parent;
		File directory = new File(SRC_FOLDER);
		 
    	//make sure directory exists
    	if(!directory.exists()){
 
           System.out.println("Source folder does not exist. Please check again.");
           System.exit(0);
 
        }else{
 
           try{
        	   
               delete(directory);
        	
           }catch(Exception e){
        	   System.out.println(e.toString());
               System.out.println("Some problem occured while performing operation.");
               System.exit(0);
           }
        }
 
    	System.out.println("Execution completed. Kindly update the project.");
	}
	
	/**
	 * The function checks whether global, web and libs folder exists in Framework and in turn it's helper method createJarArchive(File, File[])
	 */	
	private void convertToJar()
	{
		//Steps:
	    //1) Create two folders with name globalsrc and websrc
		//2) Within those folder make two sub folders with name framework_global and framework_web
		//4) First of all copy all the files from FrameworkSource.web to framework_web folder
		//5) Similarly copy all the files from FrameworkSource.global to framework_global folder
		try {
			
			String globalSrc = System.getProperty("user.dir")+"\\src\\main\\java\\FrameworkSource\\global";
			String webSrc = System.getProperty("user.dir")+"\\src\\main\\java\\FrameworkSource\\web";
			String libs = System.getProperty("user.dir")+"\\libs";
			String globalJar = System.getProperty("user.dir")+"\\libs\\framework_global.jar";
			String webJar = System.getProperty("user.dir")+"\\libs\\framework_web.jar";

			//Check whether FrameworkSource folder exists
			File dir = new File(System.getProperty("user.dir")+"\\src\\main\\java\\FrameworkSource");
			File global = new File(globalSrc);
			File[] globalFiles = global.listFiles();
			//System.out.println(globalFiles.length);
			File web = new File(webSrc);
			File[] webFiles = web.listFiles();
			//System.out.println(webFiles.length);
			//File lib = new File(libs);
			File libsGlobal = new File(globalJar);
			File libsWeb = new File(webJar);
			if(dir.exists()==true)
			{
				if(global.exists()==true && web.exists()==true)
				{
		    		//Create two folders and sub folders inside it
		    	//	new File(System.getProperty("user.dir")+"\\websrc\\framework_web").mkdirs();
		    	//	new File(System.getProperty("user.dir")+"\\globalsrc\\framework_global").mkdirs();
		    		
		    		//Copy files from FrameworkSrc to these folders
		    		File src1 = new File(System.getProperty("user.dir")+"\\src\\main\\java\\FrameworkSource\\web");
					File dest1 = new File(System.getProperty("user.dir")+"\\web\\framework_web");
					FileUtils.copyDirectory(src1, dest1);
					
		    		File src2 = new File(System.getProperty("user.dir")+"\\src\\main\\java\\FrameworkSource\\global");
					File dest2 = new File(System.getProperty("user.dir")+"\\global\\framework_global");
					FileUtils.copyDirectory(src2, dest2);
					Thread.sleep(3000);
							    		
		    		//Now rename the package and imports inside framework_web and framework_global
					File globalfolder = new File(System.getProperty("user.dir")+"\\global\\framework_global");
					File webfolder = new File(System.getProperty("user.dir")+"\\web\\framework_web");
					searchAndReplaceFiles2(webfolder,globalfolder);

		    		//Then for making jars make a folder global/web. Under it a folder named framework_web/framework_global. Then remove instances of package and import
					File globalsrc = new File(System.getProperty("user.dir")+"\\global");
					File[] globalsrcFiles = globalsrc.listFiles();
					
					File websrc = new File(System.getProperty("user.dir")+"\\web");
					File[] websrcFiles = websrc.listFiles();
					
					createJarArchive(libsGlobal, globalsrcFiles);
		    		createJarArchive(libsWeb, websrcFiles);
				}
				
				else {
					System.out.println("Please fetch the framework source files and try again.");
		            System.exit(0);
				}
			}
			
			else if(dir.exists()==false) {
				System.out.println("Please fetch the framework source files and try again.");
	            System.exit(0);
			}
		}
		
		catch(Exception e){
     	   System.out.println(e.toString());
            System.out.println("Some problem occured while performing operation.");
            System.exit(0);
        }
	}
	
	/**
	 * The function is a helper method which actually creates the jars inside libs folder
	 * @param archiveFile is file parameter which takes name of jar file and tobeJared contains files to be jared
	 */
	private void createJarArchive(File archiveFile, File[] tobeJared) {
	    try {
	      byte buffer[] = new byte[BUFFER_SIZE];
	      // Open archive file
	      FileOutputStream stream = new FileOutputStream(archiveFile);
	      JarOutputStream out = new JarOutputStream(stream, new Manifest());

	      for (int i = 0; i < tobeJared.length; i++) {
	        if (tobeJared[i] == null || !tobeJared[i].exists()
	            || tobeJared[i].isDirectory())
	          continue; // Just in case...
	        //System.out.println("Adding " + tobeJared[i].getName());

	        // Add archive entry
	        JarEntry jarAdd = new JarEntry(tobeJared[i].getName());
	        jarAdd.setTime(tobeJared[i].lastModified());
	        out.putNextEntry(jarAdd);

	        // Write file to archive
	        FileInputStream in = new FileInputStream(tobeJared[i]);
	        while (true) {
	          int nRead = in.read(buffer, 0, buffer.length);
	          if (nRead <= 0)
	            break;
	          out.write(buffer, 0, nRead);
	        }
	        in.close();
	      }

	      out.close();
	      stream.close();
	     //System.out.println("Execution completed.");
	    } catch (Exception ex) {
	    	System.out.println(ex.toString());
            System.out.println("Some problem occured while performing operation.");
            System.exit(0);
	    }
	  }
	
	/**
	 * The function deletes the entire folder structure as defined in file parameter
	 * @param File parameter stores the name of file/folder to be deleted
	 * @throws IOException
	 */
	private void delete(File file)
	    	throws IOException{
	 
	    	if(file.isDirectory()){
	 
	    		//directory is empty, then delete it
	    		if(file.list().length==0){
	    			
	    		   file.delete();
	    		 //  System.out.println("Directory is deleted : " 
	             //                                   + file.getAbsolutePath());
	    			
	    		}else{
	    			
	    		   //list all the directory contents
	        	   String files[] = file.list();
	     
	        	   for (String temp : files) {
	        	      //construct the file structure
	        	      File fileDelete = new File(file, temp);
	        	      	        		 
	        	      //recursive delete
	        	     delete(fileDelete);
	        	   }
	        		
	        	   //check the directory again, if empty then delete it
	        	   if(file.list().length==0){
	           	     file.delete();
	        	  //   System.out.println("Directory is deleted : " 
	              //                                    + file.getAbsolutePath());
	        	   }
	    		}
	    		
	    	}else{
	    		//if file, then delete it
	    		file.delete();
	    		//System.out.println("File is deleted : " + file.getAbsolutePath());
	    	}
	    }
	
	
	/**
	 * The function creates a test template
	 * @param filename stores the name of the test file to be created
	 * @throws Exception
	 */	
	private void createJavaFile(String filename) throws Exception
	{
		String splitname[] = filename.split("\\.");
		String classname = splitname[0];
		String newfile = System.getProperty("user.dir") +"\\src\\test\\java\\Tests\\"+ filename;
		FileWriter writer = new FileWriter(newfile);
		writer.write("package Tests;"+"\r\n"+"\r\n"+"import framework_web.*;"+"\r\n"+"//import FrameworkSource.web.*;"+"\r\n"+"import framework_global.*;"+"\r\n"+"//import FrameworkSource.global.*;"+"\r\n"+"import framework_global.reporter.*;"+"\r\n"+"//import FrameworkSource.global.reporter.*;"+"\r\n"+"import org.junit.*;"+"\r\n"+"\r\n"+"public class "+classname+" {"+"\r\n"+"\r\n"+"\t"+"@Test"+
		"\r\n"+"\t"+"public void main() throws Exception"+"\r\n"+"\t"+"{"+"\r\n"+"\t"+"DataReader datareader = new DataReader(\"Name\");"+"\r\n"+"\t"+"new "+classname+"().new TestFlow().driver(datareader);"+"\r\n"+"\t"+"}"+"\r\n"+"\r\n"+"private class TestFlow {"+"\r\n"+"\r\n"+"\t"+"Browser browser = new Browser();"+"\r\n"+"\t"+"Page page = new Page(browser);"+"\r\n"+"\r\n"+"\r\t"+"private void driver(DataReader datareader) throws Exception"
		+"\r\n"+"\t"+"{"+"\r\n"+"\t\t"+"String browser[] = datareader.browser();"+"\r\n"+"\t\t"+"String[][] TestcaseData = datareader.getData();"+"\r\n" + 
		"\r\n"+"\t\t"+"for(int i=0;i<datareader.noOfTimes();i++)"+"\r\n"+"\t\t"+"{"+"\r\n"+"\t\t\t"+"String currentData[] = datareader.SingleArr(TestcaseData,i);"+"\r\n"+"\t\t\t"+"for(int j=0;j<datareader.noOfBrowsers();j++)"+"\r\n"+"\t\t\t"+"{"+"\r\n"+"\t\t\t\t"+"\r\n"+"\t\t\t\t"+"//Call methods"+"\r\n"+"\t\t\t\t"+"open_browser(browser[j],datareader.getURL());"
		+"\r\n"+"\t\t\t\t"+"close_browser();"+"\r\n"+"\t\t\t"+"}"+"\r\n"+"\t\t"+"}"+"\r\n"+"\t"+"}"+"\r\n"+"\t"+"private void open_browser(String browserType, String url) throws Exception"+"\r\n"+"\t"+"{"+"\r\n"+"\t\t"+"browser.InitiateBrowser(browserType);"+"\r\n"+"\t\t"+"browser.Maximize();"+"\r\n"+"\t\t"+"browser.NavigateURL(url);"+"\r\n"+"\t"+"}"+"\r\n"+"\r\n"+"\t"+"private void close_browser() throws Exception"
		+"\r\n"+"\t"+""+"{"+"\r\n"+"\t\t"+"browser.Quit();"+"\r\n"+"\t"+"}"+"\r\n"+"\r\n"+"}"+"\r\n"+"}");
        writer.close();
        //System.out.println("New file created. Check the Tests folder.");
	}
	/**
	 * The function checks for existence of specific LOB inside UserDefinedFunctions and in turn call it's helper method UDFCloneHelper
	 * @param lob is name of specific LOB and gitPath is path where git is installed
	 * @throws IOException 
	 */
	private void fetchUDF(String lob, String gitPath) throws IOException
	{
		 //Fetching operation will be performed from master branch only
		 String folderName = "UserDefinedFunctions";
		 String folderLocation = System.getProperty("user.dir")+"\\src\\main\\java\\"+folderName;
		 String tempPath = folderLocation+"\\temp.txt";
		 String git = gitPath;

		 File dir = new File(folderLocation);
		// File[] files = dir.listFiles();
		 
		 //First delete temp file
		 File temp1 = new File(tempPath);
		 if(temp1.exists()==true)
		 {
				temp1.delete(); //Deleting the temp.txt file
		 }
		 
		 //Now check whether LOB folder exists
		 File lobDir = new File(folderLocation+"\\"+lob);
		 if(lobDir.exists()==true)
		 {
			 //Show popup whether to deleted
			 JPanel panel = new JPanel();
			 int result = JOptionPane.showConfirmDialog(panel, "Current "+lob+" files will be updated. Click Yes to proceed.", 
				       "Warning", JOptionPane.INFORMATION_MESSAGE);   
			 
			 if (result == JOptionPane.OK_OPTION)
			 {
				 System.out.println("Execution in progress. Please wait.");
				// File temp = new File(folderLocation+);
				 File[] curFiles = lobDir.listFiles(); //Delete lob current files
					 for(int i =0;i<curFiles.length;i++){ 
					curFiles[i].delete();
					 }
			UDFCloneHelper(lob,git); //Then clone files
			}
			 
			 else if (result == JOptionPane.CANCEL_OPTION)
			 {
				 System.out.println(lob+" files didn't updated");
			 }
			 
			 else if (result == JOptionPane.NO_OPTION)
			 {
				 System.out.println(lob+" files didn't updated");
			 }
			 
			 else if (result == JOptionPane.CLOSED_OPTION)
			 {
				 System.out.println(lob+" files didn't updated");
			 }
			 
		 }
		 
		 else if(lobDir.exists()==false)
		 {
			 	System.out.println("Execution in progress. Please wait.");
				new File(System.getProperty("user.dir")+"\\src\\main\\java\\UserDefinedFunctions\\"+lob).mkdirs();
				UDFCloneHelper(lob,git); //Then clone files
				
		 }

	}//End of method
	
	/**
	 * This is a helper method which clones LOB specific UDF to UserDefinedFunctions
	 * @param lob is name of specific LOB and gitPath is path where git is installed
	 * @throws IOException 
	 */
	private void UDFCloneHelper(String lob, String git) throws IOException
	{
		// String folderName = "UserDefinedFunctions";
		 String folderLocation = System.getProperty("user.dir")+"\\src\\main\\java\\UserDefinedFunctions\\"+lob;
		 String shPath = git;
		// String shPath = "C:\\Program Files\\Git\\bin\\sh.exe";
		 String gitPath = "http://"+ACF2+"@bitbucket.sunlifecorp.com:7990/scm/tcoe/agiletestframework.git";
		 String gitFolderPath = "UDF/WEB/"+lob+"/*";
		
		 Runtime rt = Runtime.getRuntime();
		 
		 try {
		 
			//Process p = rt.exec("cmd.exe /c "+shPath+" --login -i -c & cd src\\main\\java & mkdir UdfClone & cd UdfClone & git init & git remote add origin "+gitPath+" & git config core.sparsecheckout true & echo "+gitFolderPath+" >> .git/info/sparse-checkout & git pull origin master");
			
			//System.out.println("\""+shPath+"\" --login -i -c \"cd src/main/java; mkdir UdfClone; cd UdfClone; git init; git remote add origin "+gitPath+"; git config core.sparsecheckout true; echo "+gitFolderPath+" >> .git/info/sparse-checkout; git pull origin master\"");

			Process p = rt.exec("\""+shPath+"\" --login -i -c \"cd src/main/java; mkdir UdfClone; cd UdfClone; git init; git remote add origin "+gitPath+"; git config core.sparsecheckout true; echo "+gitFolderPath+" >> .git/info/sparse-checkout; git pull origin master\"");
			
			p.waitFor();
			
			File src = new File(System.getProperty("user.dir")+"\\src\\main\\java\\UdfClone\\UDF\\WEB\\"+lob);
			File dest = new File(folderLocation);
			FileUtils.copyDirectory(src, dest);
			
			Thread.sleep(3000);
			
			File UdfClone = new File(System.getProperty("user.dir")+"\\src\\main\\java\\UdfClone");
			delete(UdfClone);
			UdfClone.delete();
			
			System.out.println(lob+" function libraries successfully cloned to UserDefinedFunctions.");
			
		 }
		 
		 catch(Exception e)
		 {
		//System.out.println("ERROR. Check if git is installed on your machine.");
      	   System.out.println(e.toString());
           System.out.println("Some problem occured while performing operation.");
			File UdfClone = new File(System.getProperty("user.dir")+"\\src\\main\\java\\UdfClone");
			delete(UdfClone);
			UdfClone.delete();
           System.exit(0);
		 }	 
	}
	
	/**
	 * The function checks for existence of libs and FrameworkSource folder and in turn calls it's helper function srcjarclone
	 * @param attr takes a string value and gitPath is path where git is installed
	 * @throws IOException 
	 */
	private void frameworkCloneHelper(String attr, String gitPath) throws IOException
	{
		File dir = new File(System.getProperty("user.dir")+"\\src\\main\\java\\FrameworkSource");
		String git = gitPath;

		if(attr.equalsIgnoreCase("src"))
		{
			//1. Check if the FrameworkSource folder exists.
			// There are two scenarios- First if it not exists then create a package with name FrameworkSource.
			// I think we don't need it---under it create two folders with name global and web
			//Clone the framework source from test in a dummy folder named "framworkClone"
			//Copy it's global and web folder to Framework Source folder
			//Delete the dummy folder
			//Display update message
			
	        boolean exists = dir.exists();
	        if(exists==false) //If not exists
	        {
	    		dir.mkdir(); //Create a folder named FrameworkSource
	    		new File(System.getProperty("user.dir")+"\\src\\main\\java\\FrameworkSource\\global").mkdirs();
	    		new File(System.getProperty("user.dir")+"\\src\\main\\java\\FrameworkSource\\web").mkdirs();
				srcjarclone("src",git);
	        }
	        
	        else if(exists==true) //If frameworkSource exists
	        {
	        	JPanel panel = new JPanel();
				 int result = JOptionPane.showConfirmDialog(panel, "Current Framework files will be updated. Click Yes to proceed.", 
					       "Warning", JOptionPane.INFORMATION_MESSAGE);   
				 
				 if (result == JOptionPane.OK_OPTION)
				 {
					// System.out.println("Execution in progress. Please wait.");
					File global = new File(System.getProperty("user.dir")+"\\src\\main\\java\\FrameworkSource\\global");
					File web = new File(System.getProperty("user.dir")+"\\src\\main\\java\\FrameworkSource\\web");

					 File[] curFiles = global.listFiles();
						 for(int i =0;i<curFiles.length;i++){ 
						curFiles[i].delete();
						 }
						 
					File[] curFiles2 = web.listFiles();
						 for(int i =0;i<curFiles2.length;i++){ 
						curFiles2[i].delete();
						 }
						 
						 srcjarclone("src",git);
				}
				 
				 else if (result == JOptionPane.CANCEL_OPTION)
				 {
					 System.out.println("CANCEL");
				 }
				 
				 else if (result == JOptionPane.NO_OPTION)
				 {
					 System.out.println("NO");

				 }
				 
				 else if (result == JOptionPane.CLOSED_OPTION)
				 {
					 System.out.println("CLOSED");

				 }
	        }

			
			
		}
		
		else if(attr.equalsIgnoreCase("jar"))
		{
			//In this just delete the jars and copy the cloned jars to it. Then refresh projects
			
			//First check whether libs folder exists
			String libs = System.getProperty("user.dir")+"\\libs";
			File lib = new File(libs);
			if(lib.exists()==false)
			{
	    		lib.mkdir();
				srcjarclone("jar",git);
			}
			else if(lib.exists()==true) {
				srcjarclone("jar",git);
			}					
		}
	}
	
	/**
	 * The function clones updated jars and framework source files from Bitbucket
	 * @param param is string containing "src or "jar" and gitPath is path where git is installed
	 * @throws IOException 
	 */
	private void srcjarclone(String param, String git) throws IOException
	{
		 String shPath = git;
	     if(param.equalsIgnoreCase("src"))
	     {
		 String folderName = "FrameworkSource";
		 String folderLocation = System.getProperty("user.dir")+"\\src\\main\\java\\"+folderName;
		// String shPath = "C:\\Program Files\\Git\\bin\\sh.exe";
		 String gitPath = "http://"+ACF2+"@bitbucket.sunlifecorp.com:7990/scm/tcoe/agiletestframework.git";
		 String gitFolderPath = "Version1.0/Test/*";
		 
		 Runtime rt = Runtime.getRuntime();
		 
		 try {
		 
			//Process p = rt.exec("cmd.exe /c "+shPath+" --login -i -c & cd src\\main\\java & mkdir FSourceClone & cd FSourceClone & git init & git remote add origin "+gitPath+" & git config core.sparsecheckout true & echo "+gitFolderPath+" >> .git/info/sparse-checkout & git pull origin master");
			//System.out.println("\""+shPath+"\" --login -i -c \"cd src/main/java; mkdir UdfClone; cd UdfClone; git init; git remote add origin "+gitPath+"; git config core.sparsecheckout true; echo "+gitFolderPath+" >> .git/info/sparse-checkout; git pull origin master\"");

			Process p = rt.exec("\""+shPath+"\" --login -i -c \"cd src/main/java; mkdir FSourceClone; cd FSourceClone; git init; git remote add origin "+gitPath+"; git config core.sparsecheckout true; echo "+gitFolderPath+" >> .git/info/sparse-checkout; git pull origin master\"");	
			
			p.waitFor();
			
			File src1 = new File(System.getProperty("user.dir")+"\\src\\main\\java\\FSourceClone\\Test\\GLOBAL\\WEB\\GlobalSrc\\framework_global");
			File src2 = new File(System.getProperty("user.dir")+"\\src\\main\\java\\FSourceClone\\Test\\WEB\\WebSrc\\framework_web");

			File dest1 = new File(folderLocation+"\\global");
			File dest2 = new File(folderLocation+"\\web");

			FileUtils.copyDirectory(src1, dest1);
			FileUtils.copyDirectory(src2, dest2);

			Thread.sleep(3000);
			/*
			File fSourceClone = new File(System.getProperty("user.dir")+"\\src\\main\\java\\FSourceClone");
			delete(fSourceClone);
			fSourceClone.delete();
			*/
			
			//Nextstep is to change the line of package and import
			searchAndReplaceFiles();
			
			System.out.println("Files successfully cloned to FrameworkSource. Please update the project.");
			
		 }
		 
		 catch(Exception e)
		 {
		   //System.out.println("ERROR. Check if git is installed on your machine.");
      	   System.out.println(e.toString());
           System.out.println("Some problem occured while performing operation.");
			File fSourceClone = new File(System.getProperty("user.dir")+"\\src\\main\\java\\FSourceClone");
			delete(fSourceClone);
			fSourceClone.delete();
           System.exit(0);
		 }	
		 
	     }//End of if
	     
	     else if(param.equalsIgnoreCase("jar"))
	     {
	    	 String folderName = "libs";
			 String folderLocation = System.getProperty("user.dir")+"\\"+folderName;
			//String shPath = "C:\\Program Files\\Git\\bin\\sh.exe";
			 String gitPath = "http://"+ACF2+"@bitbucket.sunlifecorp.com:7990/scm/tcoe/agiletestframework.git";
			 String gitFolderPath = "Version1.0/Test/*";
			 
			 Runtime rt = Runtime.getRuntime();
			 
			 try {
			 
				//Process p = rt.exec("cmd.exe /c "+shPath+" --login -i -c & mkdir FJarClone & cd FJarClone & git init & git remote add origin "+gitPath+" & git config core.sparsecheckout true & echo "+gitFolderPath+" >> .git/info/sparse-checkout & git pull origin master");
				
				//System.out.println("\""+shPath+"\" --login -i -c \"cd src/main/java; mkdir UdfClone; cd UdfClone; git init; git remote add origin "+gitPath+"; git config core.sparsecheckout true; echo "+gitFolderPath+" >> .git/info/sparse-checkout; git pull origin master\"");

				Process p = rt.exec("\""+shPath+"\" --login -i -c \"mkdir FJarClone; cd FJarClone; git init; git remote add origin "+gitPath+"; git config core.sparsecheckout true; echo "+gitFolderPath+" >> .git/info/sparse-checkout; git pull origin master\"");
								
				p.waitFor();
				
				File src1 = new File(System.getProperty("user.dir")+"\\FJarClone\\Test\\GLOBAL\\WEB\\GlobalJar");
				File src2 = new File(System.getProperty("user.dir")+"\\FJarClone\\Test\\WEB\\WebJar");
				
				File dest1 = new File(folderLocation);
				
				/*
				File[] curFiles = dest1.listFiles();
				 for(int i =0;i<curFiles.length;i++){ 
					 //System.out.println(i);
				curFiles[i].delete();  //Delete current jars
				 }
				 */
				
				Thread.sleep(2000);

				FileUtils.copyDirectory(src1, dest1);
				FileUtils.copyDirectory(src2, dest1);

				Thread.sleep(3000);
				/*
				File fJarClone = new File(System.getProperty("user.dir")+"\\FJarClone");
				delete(fJarClone);
				fJarClone.delete();
				*/
				System.out.println("Jar files updated. Please update the maven project.");
				
			 }
			 
			 catch(Exception e)
			 {
				   //System.out.println("ERROR. Check if git is installed on your machine.");
	        	   System.out.println(e.toString());
	               System.out.println("Some problem occured while performing operation.");
					File fJarClone = new File(System.getProperty("user.dir")+"\\FJarClone");
					delete(fJarClone);
					fJarClone.delete();			
	               System.exit(0);
			 }	
	     }//End of else	 
		}

	/**
	 * The function searches and replaces package and import statements according to local frameworkSource files
	 * @throws Exception
	 */
	//search and replace package name and import statements according to FrameworkSource files 
	private void searchAndReplaceFiles() throws Exception
	{
        BufferedReader reader = null;
        FileWriter writer = null;
        String line = "", oldtext = "";
        
		File global = new File(System.getProperty("user.dir")+"\\src\\main\\java\\FrameworkSource\\global");
		File web = new File(System.getProperty("user.dir")+"\\src\\main\\java\\FrameworkSource\\web");

		File[] curFiles = global.listFiles(); //Read, search and replace in all files
		 for(int i =0;i<curFiles.length;i++){ 
		 if(curFiles[i].isDirectory())
		 {
		 //check name of directory
			 //System.out.println(curFiles[i].getName());
			 String folder_name = curFiles[i].getName();
			 File innerdir = new File(System.getProperty("user.dir")+"\\src\\main\\java\\FrameworkSource\\global\\"+folder_name);
			 File[] innerdirfiles = innerdir.listFiles();
			 for(int j =0;j<innerdirfiles.length;j++){
				 reader = new BufferedReader(new FileReader(innerdirfiles[j]));
				 while((line = reader.readLine()) != null)
	            {
					 oldtext += line + "\r\n";		 
	            }
	            reader.close();

		           //To replace a line in a file

	            String newtext = oldtext.replaceAll("package framework_global."+folder_name+";","package FrameworkSource.global."+folder_name+";" );
	           String newtext1 = newtext.replaceAll("import framework_global.reporter.*;","import FrameworkSource.global.reporter.*;");
	           String newtext2 = newtext1.replaceAll("import framework_web.*;", "import FrameworkSource.web.*;");
	           String newtext3 = newtext2.replaceAll("import framework_global.reporter.Logger;", "import FrameworkSource.global.reporter.Logger;");             
	           String newtext4 = newtext3.replaceAll("import framework_global.reporter.ReportGenerator;", "import FrameworkSource.global.reporter.ReportGenerator;");
	           String newtext5 = newtext4.replaceAll("import framework_global.restutilities.*;","import FrameworkSource.global.restutilities.*;" );
	           String newtext6 = newtext5.replaceAll("import framework_global.restutilities.Response;", "import framework_global.restutilities.Response;");           	            
	           String newtext7 = newtext6.replaceAll("import framework_global.restutilities.RestConnector;", "import FrameworkSource.global.restutilities.RestConnector;");

	            writer = new FileWriter(innerdirfiles[j]);
	            //writer.write(newtext);
	            writer.write(newtext7);
	            writer.close();
	            
	            oldtext = "";
				 
			 }

		 
		 //and then rename package and imports
		 
		 }
		 //if is a normal file
		 else
		 {
			 
			 reader = new BufferedReader(new FileReader(curFiles[i]));
			 while((line = reader.readLine()) != null)
           {
				 oldtext += line + "\r\n";		 
           }
           reader.close();

	           //To replace a line in a file
           String newtext = oldtext.replaceAll("package framework_global;", "package FrameworkSource.global;" );
           String newtext1 = newtext.replaceAll("import framework_global.reporter.*;","import FrameworkSource.global.reporter.*;");
           String newtext2 = newtext1.replaceAll("import framework_web.*;", "import FrameworkSource.web.*;");
           String newtext3 = newtext2.replaceAll("import framework_global.reporter.Logger;", "import FrameworkSource.global.reporter.Logger;");
           String newtext4 = newtext3.replaceAll("import framework_global.reporter.ReportGenerator;", "import FrameworkSource.global.reporter.ReportGenerator;");
           String newtext5 = newtext4.replaceAll("import framework_global.reporter.ReportEvents;", "import FrameworkSource.global.reporter.ReportEvents;");


           writer = new FileWriter(curFiles[i]);
           //writer.write(newtext);
           writer.write(newtext5);
           writer.close();
           
           oldtext = ""; 
           
           
           }//end of else
           } 
			 
		 File[] curFiles2 = web.listFiles();
		 for(int i =0;i<curFiles2.length;i++){ 
			 
			 reader = new BufferedReader(new FileReader(curFiles2[i]));
			 while((line = reader.readLine()) != null)
           {
				 oldtext += line + "\r\n";		 
           }
           reader.close();

	           //To replace a line in a file
           String newtext = oldtext.replaceAll("package framework_web;", "package FrameworkSource.web;" );
           String newtext1 = newtext.replaceAll("import framework_global.reporter.*;","import FrameworkSource.global.reporter.*;");
           String newtext2 = newtext1.replaceAll("import framework_global.*;", "import FrameworkSource.global.*;");
           String newtext3 = newtext2.replaceAll("import framework_global.reporter.Logger;", "import FrameworkSource.global.reporter.Logger;");
           String newtext4 = newtext3.replaceAll("import framework_global.reporter.ReportGenerator;", "import FrameworkSource.global.reporter.ReportGenerator;");
           String newtext5 = newtext4.replaceAll("import framework_global.reporter.ReportEvents;", "import FrameworkSource.global.reporter.ReportEvents;");
           
           writer = new FileWriter(curFiles2[i]);
           //writer.write(newtext);
           writer.write(newtext5);
           writer.close();
           
           oldtext = "";
			 
			}
	}
	
	private void searchAndReplaceFiles2(File web,File global) throws Exception
	{
        BufferedReader reader = null;
        FileWriter writer = null;
        String line = "", oldtext = "";
        
		//File global = new File(System.getProperty("user.dir")+"\\global\\framework_global");
		//File web = new File(System.getProperty("user.dir")+"\\web\\framework_web");

		
		File[] curFiles = global.listFiles(); //Read, search and replace in all files
		 for(int i =0;i<curFiles.length;i++){ 
			// System.out.println(curFiles[i].getName());
		 if(curFiles[i].isDirectory())
		 {
		 //check name of directory
			// System.out.println(curFiles[i].getName());
			 String folder_name = curFiles[i].getName();
			 //System.out.println(global.getAbsolutePath()+"\\"+folder_name);
			 File innerdir = new File(global.getAbsolutePath()+"\\"+folder_name);
			 File[] innerdirfiles = innerdir.listFiles();
			 //System.out.println(innerdirfiles.length);
			 for(int j =0;j<innerdirfiles.length;j++){
				 reader = new BufferedReader(new FileReader(innerdirfiles[j]));
				 while((line = reader.readLine()) != null)
	            {
					 oldtext += line + "\r\n";		 
	            }
	            reader.close();

		           //To replace a line in a file
	            String newtext = oldtext.replaceAll("package FrameworkSource.global."+folder_name+";", "package framework_global."+folder_name+";");
	            String newtext1 = newtext.replaceAll("import FrameworkSource.global.reporter.*;", "import framework_global.reporter.*;");
	            String newtext2 = newtext1.replaceAll("import FrameworkSource.web.*;", "import framework_web.*;");
	            String newtext3 = newtext2.replaceAll("import FrameworkSource.global.reporter.Logger;", "import framework_global.reporter.Logger;");
	            String newtext4 = newtext3.replaceAll("import FrameworkSource.global.reporter.ReportGenerator;", "import framework_global.reporter.ReportGenerator;");
	            String newtext5 = newtext4.replaceAll("import FrameworkSource.global.restutilities.*;", "import framework_global.restutilities.*;");
	            String newtext6 = newtext5.replaceAll("import FrameworkSource.global.restutilities.Response;", "import framework_global.restutilities.Response;");
	            String newtext7 = newtext6.replaceAll("import FrameworkSource.global.restutilities.RestConnector;", "import framework_global.restutilities.RestConnector;");

	            writer = new FileWriter(innerdirfiles[j]);
	            //writer.write(newtext);
	            writer.write(newtext7);
	            writer.close();
	            
	            oldtext = "";
				 
			 }

		 
		 //and then rename package and imports
		 
		 }
		 //if is a normal file
		 else
		 {
			 
			 reader = new BufferedReader(new FileReader(curFiles[i]));
			 while((line = reader.readLine()) != null)
            {
				 oldtext += line + "\r\n";		 
            }
            reader.close();

	           //To replace a line in a file
            String newtext = oldtext.replaceAll("package FrameworkSource.global;", "package framework_global;");
            String newtext1 = newtext.replaceAll("import FrameworkSource.global.reporter.*;", "import framework_global.reporter.*;");
            String newtext2 = newtext1.replaceAll("import FrameworkSource.web.*;", "import framework_web.*;");
            String newtext3 = newtext2.replaceAll("import FrameworkSource.global.reporter.Logger;", "import framework_global.reporter.Logger;");
            String newtext4 = newtext3.replaceAll("import FrameworkSource.global.reporter.ReportGenerator;", "import framework_global.reporter.ReportGenerator;");
            String newtext5 = newtext4.replaceAll("import FrameworkSource.global.reporter.ReportEvents;", "import framework_global.reporter.ReportGenerator;");


            writer = new FileWriter(curFiles[i]);
            //writer.write(newtext);
            writer.write(newtext5);
            writer.close();
            
            oldtext = ""; 
            
            
            }//end of else
            } 
			 
		 File[] curFiles2 = web.listFiles();
		 for(int i =0;i<curFiles2.length;i++){ 
			 
			 reader = new BufferedReader(new FileReader(curFiles2[i]));
			 while((line = reader.readLine()) != null)
            {
				 oldtext += line + "\r\n";		 
            }
            reader.close();

	           //To replace a line in a file
            String newtext = oldtext.replaceAll("package FrameworkSource.web;", "package framework_web;");
            String newtext1 = newtext.replaceAll("import FrameworkSource.global.reporter.*;", "import framework_global.reporter.*;");
            String newtext2 = newtext1.replaceAll("import FrameworkSource.global.*;", "import framework_global.*;");
            String newtext3 = newtext2.replaceAll("import FrameworkSource.global.reporter.Logger;", "import framework_global.reporter.Logger;");
            String newtext4 = newtext3.replaceAll("import FrameworkSource.global.reporter.ReportGenerator;", "import framework_global.reporter.ReportGenerator;");
            String newtext5 = newtext4.replaceAll("import FrameworkSource.global.reporter.ReportEvents;", "import framework_global.reporter.ReportGenerator;");

            
            writer = new FileWriter(curFiles2[i]);
            //writer.write(newtext);
            writer.write(newtext5);
            writer.close();
            
            oldtext = "";
			 
			}
	}
	
	/**
	 * The function checks whether git is installed
	 */
	private String checkGit()
	{ 
		String shPath = "C:\\Users\\"+ACF2+"\\AppData\\Local\\Atlassian\\SourceTree\\git_local\\bin\\sh.exe";
		String shPath2 = "C:\\Program Files\\Git\\bin\\sh.exe";
		String shPath3 = "C:\\Program Files (x86)\\Git\\bin\\sh.exe";
		
		String sendPath="";
		File shPath0 = new File(shPath);
		File shPath1 = new File(shPath2);
		File shPath4 = new File(shPath3);

		if(shPath0.exists()==true)
		{
			sendPath = shPath;
		}
		
		else if(shPath1.exists()==true)
		{
			sendPath = shPath2;
		}
		
		else if(shPath4.exists()==true)
		{
			sendPath = shPath3;
		}
		
		else
			sendPath="Not Found";
		
		return sendPath;
		
	}
	
	/**
	 * This function sends mail to admin in case of any changes to Bitbucket repository 
	 * @param udfsrc is a string expecting "udf" or "src", lob contains name of specific LOB and git is the path where git is installed
	 * @throws Exception
	 */
	private void sendMail(String udfsrc, String lob) throws Exception
	{
			final String username = "";
	      	final String password = "";
			
	      	String host = "smtp.ca.sunlife";
			Properties props = new Properties();
		    props.put("mail.smtp.auth", "true");
		    props.put("mail.smtp.starttls.enable", "true");
		    props.put("mail.smtp.host", host);
		    props.put("mail.smtp.port", "25");
		    props.put("mail.smtp.ssl.trust",host);
			//Properties props = System.getProperties();
			//props.put("mail.smtp.host", "your server here");
			
			Session session = Session.getInstance(props,
			         new javax.mail.Authenticator() {
			            protected PasswordAuthentication getPasswordAuthentication() {
			               return new PasswordAuthentication(username, password);
			            }
			         });

			
			try {
				MimeMessage msg = new MimeMessage(session);
				  //set message headers

			      msg.setFrom(new InternetAddress("DEV_TEST_COMMUNITY"));

			      if(udfsrc.equals("udf"))
			      {
			      msg.setSubject(ACF2 +" updated WEB UDF files of "+lob+" under contribute branch on "+new Date().toString(),"UTF-8");
			      }
			      else
				      msg.setSubject(ACF2 +" updated WEB Framework Source files under contribute branch on "+new Date().toString(),"UTF-8");

			      msg.setSentDate(new Date());

			      msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse("vivek.singh@sunlife.com,deepankar.pant@sunlife.com,akshey.taneja@sunlife.com,indumathi.sennakrishnan@sunlife.com,ankur.aggarwal@sunlife.com", false));
			      			      
			   // Create the message part
			     BodyPart messageBody = new MimeBodyPart();
			        
			       
			    // Create a multipart message
			         Multipart multipart = new MimeMultipart();
					 messageBody.setContent("Hi, A reminder to update files of master branch.", "text/html");
					 
					// Set text message part
			         multipart.addBodyPart(messageBody);
			 				         
			        // Send the complete message parts
			         msg.setContent(multipart);
			    	  Transport.send(msg);
			     			     
			     
				} catch (Exception e) {
				  // ...
		        	   System.out.println(e.toString());
		               System.out.println("Some problem occured while performing operation.");

		               if(udfsrc.equals("udf"))
		               {
		             //Lastly delete Clone folder
           			File Clone = new File(System.getProperty("user.dir")+"\\Clone1");
           			delete(Clone);
           			Clone.delete();
		               }
		            
		            else if(udfsrc.equals("src"))
		               {
					File Clone = new File(System.getProperty("user.dir")+"\\Clone1");
					delete(Clone);
					Clone.delete();
					File global = new File(System.getProperty("user.dir")+"\\globaltemp");
					File web = new File(System.getProperty("user.dir")+"\\webtemp");			
					delete(global);
					global.delete();
					delete(web);
					web.delete();
		               }
		           System.exit(0);
				}
	}
	
	/**
	 * The function copy files to recently cloned folder from Bitbucket
	 * @param udfsrc and lob are of String type 
	 * @throws Exception
	 */
	private void copyFiles(String udfsrc, String lob) throws Exception
	{

			//Make two folders global and web
			new File(System.getProperty("user.dir")+"\\globaltemp").mkdirs();
    		new File(System.getProperty("user.dir")+"\\webtemp").mkdirs();

			//Rename the few statements
			File fglobal = new File(System.getProperty("user.dir")+"\\src\\main\\java\\FrameworkSource\\global");
			File fweb = new File(System.getProperty("user.dir")+"\\src\\main\\java\\FrameworkSource\\web");
			
			File global = new File(System.getProperty("user.dir")+"\\globaltemp");
			File web = new File(System.getProperty("user.dir")+"\\webtemp");
			
			
			//Copy files from src to new folders
			FileUtils.copyDirectory(fglobal, global);
			FileUtils.copyDirectory(fweb, web);
			
			//System.out.println("searchAndReplaceFiles2");
			searchAndReplaceFiles2(web, global);
			 
	}
	
	/**
	 * This function helps in cloning specific folders from Bitbucket
	 * @param param, string and lob are of String type
	 * @throws IOException 
	 */
	private void clone(String param, String git, String lob) throws IOException
	{
		 String shPath = git;
	     if(param.equalsIgnoreCase("src"))
	     {
		// String shPath = "C:\\Program Files\\Git\\bin\\sh.exe";
		 String gitPath = "http://"+ACF2+"@bitbucket.sunlifecorp.com:7990/scm/tcoe/agiletestframework.git";
		 String gitFolderPath = "FrameworkTemplate/*";
		 String globalLocation = System.getProperty("user.dir")+"\\src\\main\\java\\FrameworkSource\\global";
		 String webLocation = System.getProperty("user.dir")+"\\src\\main\\java\\FrameworkSource\\web";
		 File globalDir = new File(globalLocation);
		 File webDir = new File(webLocation);
		 if(globalDir.exists()==false || webDir.exists()==false)
		 {
			 System.out.println("First fetch the framework source files.");
			 System.exit(0);
		 }
		 
		 Runtime rt = Runtime.getRuntime();
		 
		 try {
			//Process p = rt.exec("cmd.exe /c "+shPath+" --login -i -c & cd src\\main\\java & mkdir Clone1 & cd Clone1 & git init & git remote add origin "+gitPath+" & git config core.sparsecheckout true & echo "+gitFolderPath+" >> .git/info/sparse-checkout & git pull origin master");
			//System.out.println("\""+shPath+"\" --login -i -c \"mkdir Clone1; cd Clone1; git init; git remote add origin "+gitPath+"; git config core.sparsecheckout true; echo "+gitFolderPath+" >> .git/info/sparse-checkout; git pull origin contribute\"");

			Process p = rt.exec("\""+shPath+"\" --login -i -c \"mkdir Clone1; cd Clone1; git init; git remote add origin "+gitPath+"; git config core.sparsecheckout true; echo "+gitFolderPath+" >> .git/info/sparse-checkout; git pull origin contribute\"");
			
			p.waitFor();		
			
			copyFiles("temp","");
			
			
			//We have clone from contribute branch and now just push it to the branch
			File websrc = new File(System.getProperty("user.dir")+"\\webtemp");
			File webdest = new File(System.getProperty("user.dir")+"\\Clone1\\FrameworkTemplate\\src\\main\\java\\FrameworkSource\\web");
			File globalsrc = new File(System.getProperty("user.dir")+"\\globaltemp");
			File globaldest = new File(System.getProperty("user.dir")+"\\Clone1\\FrameworkTemplate\\src\\main\\java\\FrameworkSource\\global");
			
			FileUtils.copyDirectory(websrc, webdest);
			FileUtils.copyDirectory(globalsrc, globaldest);
			
			//System.out.println("\""+shPath+"\" --login -i -c \"cd Clone1; git checkout contribute; git add -A; git commit -a -m \"Updated by "+ACF2+" on "+new Date().toString()+"\"; git push origin contribute\"");

			
			//Now just push 
			p = rt.exec("\""+shPath+"\" --login -i -c \"cd Clone1; git checkout contribute; git add -A; git commit -m \"LastUpdatedBy"+ACF2+"\"; git push origin contribute\"");

			p.waitFor();
			
		 }
		 
		 catch(Exception e)
		 {
		   System.out.println("ERROR. Check if git is installed on your machine.");
      	   System.out.println(e.toString());
           System.out.println("Some problem occured while performing operation.");
			File Clone = new File(System.getProperty("user.dir")+"\\Clone1");
			delete(Clone);
			Clone.delete();
			File global = new File(System.getProperty("user.dir")+"\\globaltemp");
			File web = new File(System.getProperty("user.dir")+"\\webtemp");			
			delete(global);
			global.delete();
			delete(web);
			web.delete();
           System.exit(0);
		 }	
		 
	     }//End of if
	     
	     else if(param.equalsIgnoreCase("udf"))
	     {
			 String folderName = "UserDefinedFunctions";
			 String folderLocation = System.getProperty("user.dir")+"\\src\\main\\java\\"+folderName;
			 File lobDir = new File(folderLocation+"\\"+lob);
			 if(lobDir.exists()==false)
			 {
				 System.out.println("First fetch the "+lob+" UserDefinedFunctions.");
				 System.exit(0);
			 }
			//String shPath = "C:\\Program Files\\Git\\bin\\sh.exe";
			 String gitPath = "http://"+ACF2+"@bitbucket.sunlifecorp.com:7990/scm/tcoe/agiletestframework.git";

			 String gitFolderPath = "UDF/WEB/"+lob+"/*";
			 
			 Runtime rt = Runtime.getRuntime();
			 
			 try {
			 
				//Process p = rt.exec("cmd.exe /c "+shPath+" --login -i -c & cd src\\main\\java & mkdir Clone1 & cd Clone1 & git init & git remote add origin "+gitPath+" & git config core.sparsecheckout true & echo "+gitFolderPath+" >> .git/info/sparse-checkout & git pull origin master");
				
				//System.out.println("\""+shPath+"\" --login -i -c \"mkdir Clone1; cd Clone1; git init; git remote add origin "+gitPath+"; git config core.sparsecheckout true; echo "+gitFolderPath+" >> .git/info/sparse-checkout; git pull origin contribute\"");

				Process p = rt.exec("\""+shPath+"\" --login -i -c \"mkdir Clone1; cd Clone1; git init; git remote add origin "+gitPath+"; git config core.sparsecheckout true; echo "+gitFolderPath+" >> .git/info/sparse-checkout; git pull origin contribute\"");
				
				p.waitFor();
	
				
				//We have clone from contribute branch and now just push it to the branch
				File udfsrc = new File(System.getProperty("user.dir")+"\\src\\main\\java\\UserDefinedFunctions\\"+lob);
				File udfdest = new File(System.getProperty("user.dir")+"\\Clone1\\UDF\\WEB\\"+lob);
				FileUtils.copyDirectory(udfsrc, udfdest);
				
				//System.out.println("\""+shPath+"\" --login -i -c \"cd Clone1; git checkout contribute; git add -A; git commit -a -m \"Updated by "+ACF2+" on "+new Date().toString()+"\"; git push origin contribute\"");

				
				//Now just push 
				p = rt.exec("\""+shPath+"\" --login -i -c \"cd Clone1; git checkout contribute; git add -A; git commit -m \"LastUpdatedBy"+ACF2+"\"; git push origin contribute\"");

				p.waitFor();
    			
				
			 }
			 
			 catch(Exception e)
			 {
				// System.out.println("ERROR. Check if git is installed on your machine.");
	        	   System.out.println(e.toString());
	               System.out.println("Some problem occured while performing operation.");
	    			//Lastly delete Clone folder
	    			File Clone = new File(System.getProperty("user.dir")+"\\Clone1");
	    			delete(Clone);
	    			Clone.delete();
	               System.exit(0);
			 }	
	     }//End of else
		
	}
	
	/**
	 * This is a main function
	 */
	public static void main() {
		// TODO Auto-generated method stub
		SetUpRun s = new SetUpRun();

		try{
		File inputFile = new File(System.getProperty("user.dir")+"\\src\\test\\resources\\configuration\\settings.xml");
        SAXBuilder saxBuilder = new SAXBuilder();
        Document document = saxBuilder.build(inputFile);
        //System.out.println("Root element :" + document.getRootElement().getName());
        Element classElement = document.getRootElement();
        List<Element> list = classElement.getChildren();
        
        for (int temp = 0; temp < list.size(); temp++) {    
            Element element = list.get(temp); //
            Attribute attribute =  element.getAttribute("set");
          
            if(element.getName().equalsIgnoreCase("initial-setup"))
            {
                //System.out.println("Parent is "+element.getName()); //initial-setup
            	if(attribute.getValue().equalsIgnoreCase("true"))
            	{
                    List<Element> list1 = element.getChildren(); //children of initial-setup
                    for(int i=0; i<list1.size(); i++)
                    {
                    	 Element element1 = list1.get(i); 
                         Attribute attribute1 =  element1.getAttribute("set");
                         if(element1.getName().equalsIgnoreCase("update-corrupt-files"))
                         {
                        	 if(attribute1.getValue().equalsIgnoreCase("true"))
                         	{
                         		//Create a sample java file so that user don't have to waste time creating a new java file
                         		//System.out.println(element1.getChild("parent-folder").getText());
                         		s.deleteCorruptedJars(element1.getChild("parent-folder").getText());
                         		
                         	}
                         
                         }
                         
                         else if(element1.getName().equalsIgnoreCase("create-test-template"))
                         {
                        	 if(attribute1.getValue().equalsIgnoreCase("true"))
                         	{
                         		//Create a sample java file so that user don't have to waste time creating a new java file
                         		//System.out.println(element1.getChild("file-name").getText());
                         		String fileName = element1.getChild("file-name").getText().toString();
                         		if(fileName.contains("."))
                         		{
                         		    //System.out.println("string contains dot");
                         			//File dir = new File(System.getProperty("user.dir")+"\\src\\test\\java\\Tests");
                         			//String filename = file + ".MOD";
                         			boolean check = new File(System.getProperty("user.dir")+"\\src\\test\\java\\Tests", fileName).exists();
                         			if(check==true)
                         			{
                         				 //Show popup whether to overwrite
                         				 JPanel panel = new JPanel();
                         				 int result = JOptionPane.showConfirmDialog(panel, fileName+" already exists in Tests package. Do you want to overwrite?", 
                         					       "Warning", JOptionPane.INFORMATION_MESSAGE); 
                         				
                         				 if (result == JOptionPane.OK_OPTION)
                         				 {
                         					s.createJavaFile(fileName);
                         					System.out.println(fileName+" file is overwritten.");
                         				}
                         			}
                         			else
                         			{
                         				s.createJavaFile(fileName);
                         				System.out.println("New file created. Check the Tests folder.");         
                         				}
                         			
                         			
                         			//s.createJavaFile(fileName);
                         		}
                         		else
                         		{
                         			fileName = fileName.concat(".java");
                         			boolean check = new File(System.getProperty("user.dir")+"\\src\\test\\java\\Tests", fileName).exists();
                         			if(check==true)
                         			{
                         				 //Show popup whether to overwrite
                         				 JPanel panel = new JPanel();
                         				 int result = JOptionPane.showConfirmDialog(panel, fileName+" already exists in Tests package. Do you want to overwrite?", 
                         					       "Warning", JOptionPane.INFORMATION_MESSAGE); 
                         				
                         				 if (result == JOptionPane.OK_OPTION)
                         				 {
                         					s.createJavaFile(fileName);
                         					System.out.println(fileName+" file is overwritten.");
                         				}
                         			}
                         			else
                         			{
                         				s.createJavaFile(fileName);
                         				System.out.println("New file created. Check the Tests folder.");         
                         				}
                         			
                     				//s.createJavaFile(fileName);
                         		}
                         	}
                         
                         }                  
                    } //End of initial-setup size()
            } //If the parent initial-setup is true
            }//End of initial setup
            	
            
            else if(element.getName().equalsIgnoreCase("utilities"))
            {
                //System.out.println("Parent is "+element.getName()); //initial-setup
            	if(attribute.getValue().equalsIgnoreCase("true"))
            	{
                    List<Element> list1 = element.getChildren(); //children of initial-setup
                    for(int i=0; i<list1.size(); i++)
                    {
                    	 Element element1 = list1.get(i); 
                         Attribute attribute1 =  element1.getAttribute("set");
                         if(element1.getName().equalsIgnoreCase("convert-to-jar"))
                         {
                        	 if(attribute1.getValue().equalsIgnoreCase("true"))
                         	{
                         		//System.out.println(element1.getChild("framework-files").getText());
                         		if(element1.getChild("framework-files").getText().equalsIgnoreCase("true"))
                         		{
                         			//File srcfolder1 = new File(System.getProperty("user.dir")+"\\web\\framework_web");
                         			//File srcfolder2 = new File(System.getProperty("user.dir")+"\\global\\framework_global");
                         			
                         			File srcfolder1 = new File(System.getProperty("user.dir")+"\\web");
                         			File srcfolder2 = new File(System.getProperty("user.dir")+"\\global");
                         			
                         			
                         			if(srcfolder1.exists()==true && srcfolder2.exists()==true )
                         			{	
                         				new File(System.getProperty("user.dir")+"\\web\\framework_web").mkdirs();
                         				new File(System.getProperty("user.dir")+"\\global\\framework_global").mkdirs();
                           		 System.out.println("Execution in progress. Please wait.");
                        		 s.convertToJar();
                        		 System.out.println("Jars sucessfully created to libs folder. Please update the maven project.");
                        			
                        		 /*
                        		 File webdirectory = new File(System.getProperty("user.dir")+"\\web\\framework_web");
                        			File globaldirectory = new File(System.getProperty("user.dir")+"\\global\\framework_global");
                        			s.delete(webdirectory);
                        			s.delete(globaldirectory);
                        			*/


                        		 
                        		 // System.out.println("Now right-click on web and global folders and export them as JAR file inside libs folder.");
                         			}
                         			else
                         			{
                         				System.out.println("Please create source folders with name web and global outside src folders.");
                         				
                         			}

                         		}
                         		else
                         			System.out.println("No operation done. Value of framework-files is not set to true.");
                         	}          
                         }             
                    } //End of utilities size()
                } //If the parent utilities is true
                }//End of utilities setup
            
            else if(element.getName().equalsIgnoreCase("framework-operations"))
            {
            	if(attribute.getValue().equalsIgnoreCase("true"))
            	{
                    List<Element> list1 = element.getChildren(); //children of initial-setup
                    for(int i=0; i<list1.size(); i++)
                    {
                    	 Element element1 = list1.get(i); 
                         Attribute attribute1 =  element1.getAttribute("set");
                  //       System.out.println(element1.getName());
                         if(element1.getName().equalsIgnoreCase("udf"))  //Sub parent udf
                         {
                        	 if(attribute1.getValue().equalsIgnoreCase("true"))
                         	{
                         		//Create a sample java file so that user don't have to waste time creating a new java file
                         		//System.out.println(element1.getChild("parent-folder").getText());
                        		 
                                 List<Element> list2 = element1.getChildren(); //children of web
                                 for(int j=0; j<list2.size(); j++)
                                 {
                                	 Element element2 = list2.get(j);
                                     Attribute attribute2 =  element2.getAttribute("set");
                    //                 System.out.println(element2.getName()); //Sub parent udf fetch
                                     if(element2.getName().equalsIgnoreCase("udf-fetch"))
                                     {
                                    	 if(attribute2.getValue().equalsIgnoreCase("true"))
                                     	{
                                    		 //Here we have to check whether git is installed or not
                                    		 String gitPath = s.checkGit();
                                    		 
                                    		 if(!gitPath.equalsIgnoreCase("Not Found"))
                                             {
                                      		//Check if GB is set to true
                                      		if(element2.getChild("GB").getText().equals("true"))
                                      		{
                                      			s.fetchUDF("GB",gitPath);
                                      		}
                                      	//Check if GRS is set to true
                                      		if(element2.getChild("GRS").getText().equals("true"))
                                      		{
                                      			s.fetchUDF("GRS",gitPath);
                                      		}
                                      	//Check if DS is set to true
                                      		if(element2.getChild("DS").getText().equals("true"))
                                      		{
                                      			s.fetchUDF("DS",gitPath);
                                      		}
                                      	//Check if IND is set to true
                                      		if(element2.getChild("IND").getText().equals("true"))
                                      		{
                                      			s.fetchUDF("IND",gitPath);
                                      		}

                                            }// End of !gitPath.equalsIgnoreCase("Not Found")
                                    		
                                    		 else
                                                 System.out.println("SourceTree not installed. Please install it and try again.");                                      		
                                     	}
                                     }
                                     
                                     else if(element2.getName().equalsIgnoreCase("udf-upload"))
                                     {
                                    	 if(attribute2.getValue().equalsIgnoreCase("true"))
                                     	{
                                    		 //Here we have to check whether git is installed or not
                                    		 String gitPath = s.checkGit();
                                    		 
                                    		 if(!gitPath.equalsIgnoreCase("Not Found"))
                                             {
                                      		//Check if GB is set to true
                                      		if(element2.getChild("GB").getText().equals("true"))
                                      		{
                                      			
                                                System.out.println("Execution in progress. Please wait."); 

                                      		    //UDF files are cloned in Clone1 folder	
                                    			s.clone("udf",gitPath,"GB");
                                    			
                                    			//In this function check which files got changed and mail those files as attachments
                                    			s.sendMail("udf","GB");
                                    			
                                    			//Lastly delete Clone folder
                                    			File Clone = new File(System.getProperty("user.dir")+"\\Clone1");
                                    			s.delete(Clone);
                                    			Clone.delete();
                                    			
                                    			System.out.println("GB UserDefinedFunctions successfully pushed to \"contribute\" branch of AgileTestFramework repository.");
                                      		}
                                      		
                                      	//Check if GRS is set to true
                                      		if(element2.getChild("GRS").getText().equals("true"))
                                      		{
                                      			
                                                System.out.println("Execution in progress. Please wait."); 

                                      		//UDF files are cloned in Clone1 folder	
                                    			s.clone("udf",gitPath,"GRS");
                                    			
                                    			//In this function check which files got changed and mail those files as attachments
                                    			s.sendMail("udf","GRS");
                                    			
                                    			//Lastly delete Clone folder
                                    			File Clone = new File(System.getProperty("user.dir")+"\\Clone1");
                                    			s.delete(Clone);
                                    			Clone.delete();
                                    			
                                    			System.out.println("GRS UserDefinedFunctions successfully pushed to \"contribute\" branch of AgileTestFramework repository.");                                      		}
                                      		
                                      		//Check if DS is set to true
                                      		if(element2.getChild("DS").getText().equals("true"))
                                      		{
                                      		
                                                System.out.println("Execution in progress. Please wait."); 

                                      			//UDF files are cloned in Clone1 folder	
                                    			s.clone("udf",gitPath,"DS");
                                    			
                                    			//In this function check which files got changed and mail those files as attachments
                                    			s.sendMail("udf","DS");
                                    			
                                    			//Lastly delete Clone folder
                                    			File Clone = new File(System.getProperty("user.dir")+"\\Clone1");
                                    			s.delete(Clone);
                                    			Clone.delete();
                                    			
                                    			System.out.println("DS UserDefinedFunctions successfully pushed to \"contribute\" branch of AgileTestFramework repository.");
                                      		}
                                      		
                                      		//Check if DS is set to true
                                      		if(element2.getChild("IND").getText().equals("true"))
                                      		{
                                      		
                                                System.out.println("Execution in progress. Please wait."); 

                                      			//UDF files are cloned in Clone1 folder	
                                    			s.clone("udf",gitPath,"IND");
                                    			
                                    			//In this function check which files got changed and mail those files as attachments
                                    			s.sendMail("udf","IND");
                                    			
                                    			//Lastly delete Clone folder
                                    			File Clone = new File(System.getProperty("user.dir")+"\\Clone1");
                                    			s.delete(Clone);
                                    			Clone.delete();
                                    			
                                    			System.out.println("IND UserDefinedFunctions successfully pushed to \"contribute\" branch of AgileTestFramework repository.");
                                      		}

                                            }// End of !gitPath.equalsIgnoreCase("Not Found")
                                    		
                                    		 else
                                                 System.out.println("SourceTree not installed. Please install it and try again.");                                      		
                                     	}
                                     }                              	 
                                 }                         		
                         	}
                         
                         } //End of udf
                                                 
                         else if(element1.getName().equalsIgnoreCase("web"))  //Sub parent udf
                         {
                        	 if(attribute1.getValue().equalsIgnoreCase("true"))
                         	{
                         		//Create a sample java file so that user don't have to waste time creating a new java file
                         		//System.out.println(element1.getChild("parent-folder").getText());
                        		 
                                 List<Element> list2 = element1.getChildren(); //children of web
                                 for(int j=0; j<list2.size(); j++)
                                 {
                                	 Element element2 = list2.get(j);
                                     Attribute attribute2 =  element2.getAttribute("set");
                      //               System.out.println(element2.getName()); //Sub parent udf fetch
                                     if(element2.getName().equalsIgnoreCase("web-fetch"))
                                     {
                                    	 if(attribute2.getValue().equalsIgnoreCase("true"))
                                     	{
                                    		//Here we have to check whether git is installed or not
                                    		 String gitPath = s.checkGit();
                                    		 
                                    		 if(!gitPath.equalsIgnoreCase("Not Found"))
                                             {
                                    			 
                                      		//Check if jar is set to true
                                      		if(element2.getChild("jar").getText().equals("true"))
                                      		{
                                      			
                                               // System.out.println("Execution in progress. Please wait."); 

                                    			//s.frameworkCloneHelper("jar",gitPath);
                                				//File fJarClone = new File(System.getProperty("user.dir")+"\\FJarClone");
                                				//s.delete(fJarClone);
                                				//fJarClone.delete();  
                                      			
                                      	        JOptionPane.showMessageDialog(null, "This version doesn't support the required operation. Kindly switch to newer version.", "ERROR", JOptionPane.INFORMATION_MESSAGE);

                                      		}
                                      		
                                      		//Check if src is set to true
                                      		if(element2.getChild("src").getText().equals("true"))
                                      		{
                                      			
                                                //System.out.println("Execution in progress. Please wait."); 

                                    			//s.frameworkCloneHelper("src",gitPath);
                                    			//File fSourceClone = new File(System.getProperty("user.dir")+"\\src\\main\\java\\FSourceClone");
                                    			//s.delete(fSourceClone);
                                    			//fSourceClone.delete();
                                      			
                                      	        JOptionPane.showMessageDialog(null, "This version doesn't support the required operation. Kindly switch to newer version.", "ERROR", JOptionPane.INFORMATION_MESSAGE);
                                    			
                                    			
                                      		}
                                           }// End of !gitPath.equalsIgnoreCase("Not Found")
                                     		
                                    		 else
                                                 System.out.println("SourceTree not installed. Please install it and try again.");                                      		
                                    		 
                                    	                                      		
                                     	}
                                     }
                                     
                                     else if(element2.getName().equalsIgnoreCase("web-upload"))
                                     {
                                    	 if(attribute2.getValue().equalsIgnoreCase("true"))
                                     	{
                                    		//Here we have to check whether git is installed or not
                                    		 String gitPath = s.checkGit();
                                    		 
                                    		 if(!gitPath.equalsIgnoreCase("Not Found"))
                                             {
                                           		if(element2.getChild("src").getText().equals("true"))
                                          		{
                                           			//System.out.println(element2.getChild("src").getText());
                                           			//Clone the framework
                                           			//Verify the files but don't push to bit
                                           			
                                        			//System.out.println("Execution in progress. Please wait.");
                                        			//Framework files are cloned in Clone1 folder	
                                        			//s.clone("src",gitPath,"");
                                        			//In this function check which files got changed and mail those files as attachments
                                        		
                                        			
                                        			//s.sendMail("src","");
                                        			//Lastly delete Clone folder
                                					//File Clone = new File(System.getProperty("user.dir")+"\\Clone1");
                                					//s.delete(Clone);
                                					//Clone.delete();
                                					//File global = new File(System.getProperty("user.dir")+"\\globaltemp");
                                					//File web = new File(System.getProperty("user.dir")+"\\webtemp");			
                                					//s.delete(global);
                                					//global.delete();
                                					//s.delete(web);
                                					//web.delete();
                                        			
                                        			
                                        			//System.out.println("Updated Framework Source Files are successfully pushed to \"contribute\" branch of AgileTestFramework repository.");
                                          	        JOptionPane.showMessageDialog(null, "This version doesn't support the required operation. Kindly switch to newer version.", "ERROR", JOptionPane.INFORMATION_MESSAGE);
 
                                          		}
                                             }// End of !gitPath.equalsIgnoreCase("Not Found")
                                      		
                                    		 else
                                                 System.out.println("SourceTree not installed. Please install it and try again.");                                      		
                                    		 
                                    	                                      		
                                     	} //End of if web-upload is true 
                                     }  //End of parent web-upload                            	 
                                 } //End of web for loop                         		
                         	} //End of if web is true
                         
                         } //End of parent web    
                    } //End of framework-operations size()
            } //if framework-operations is true
            } //else if framework-source
            
            
        } //End of if
        
       }//End of try
		
		catch (Exception e) {
            // TODO: handle exception
			System.out.println(e.toString());
			System.out.println("Some problem occured while performing operation.");
			System.exit(0);
			}//End of catch
	}//End of psvm
}//End of class