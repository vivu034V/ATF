package Setup;

public class Setup {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		SetUpRun.main();

	}

}
