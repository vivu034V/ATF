package Tests.French;

//import framework_web.*;
import FrameworkSource.web.*;
//import framework_global.*;
import FrameworkSource.global.*;
import FrameworkSource.global.reporter.ReportEvents;
import FrameworkSource.global.reporter.ReportGenerator;
import UserDefinedFunctions.GRS.MemberSiteFL;

import java.io.IOException;

import org.junit.*;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;


public class TC01_FR {

	@Test
	public void main() throws Exception
	{
	DataReader datareader = new DataReader("TC01_FR");
	new TC01_FR().new TestFlow().driver(datareader);
	}

private class TestFlow {
	 Browser browser = new Browser();
	 Page page = new Page(browser);
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	 HashMap<String, String> testdata, commondata;
	 MemberSiteFL udf= new MemberSiteFL();	
			
	 
	private void driver(DataReader datareader) throws Exception
	{
		String browser[] = datareader.browser();
		commondata = datareader.getCommomData();

		for(int i=0;i<datareader.noOfTimes();i++)
		{
			testdata = datareader.getTestData(i);
			for(int j=0;j<datareader.noOfBrowsers();j++)
			{
				try {
				//Call methods
				open_browser(browser[j],datareader.getURL());
				login;
				}
				finally {
					close_browser();
					//ReportGenerator.Generate("true");
				}
			}
		}
	}
	private void open_browser(String browserType, String url) throws Exception
	{
		System.out.println(browserType);
		browser.InitiateBrowser(browserType);
		browser.Maximize();
		browser.NavigateURL(url);
	}
	private void login() throws Exception
	{
		page.SetCurrentPage("HomePage");
		page.Wait(5);
		Assert.assertTrue("TextBox displayed", new TextBox(browser,"userid").IsDisplayed());
		new TextBox(browser,"userid").SendKeys(testdata.get("AccessID"));
		new TextBox(browser,"Password").SendKeys(testdata.get("Password"));
		page.Wait(3);
		new Button(browser,"Submit").Click();
		page.Wait(3);
		
	}
	private void close_browser() throws Exception
	{
		udf.close(browser);
	}

	
}
}
