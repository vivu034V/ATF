package Tests;

//import framework_web.*;
import FrameworkSource.web.*;
//import framework_global.*;
import FrameworkSource.global.*;
import FrameworkSource.global.reporter.ReportEvents;
import FrameworkSource.global.reporter.ReportGenerator;
import java.io.IOException;
import org.junit.*;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;


public class TC01_FR {

	@Test
	public void main() throws Exception
	{
	DataReader datareader = new DataReader("TC01_FR");
	
	new TC01_FR().new TestFlow().driver(datareader);
	}

private class TestFlow {
	 Browser browser = new Browser();
	 Page page = new Page(browser);
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	 HashMap<String, String> testdata, commondata;
	 HashMap<String, String> testdata, commondata;
	//HashMap<String, String> commondata;
	 ReportEvents ReportEvent = new ReportEvents(browser);
	 
	
	 TestFlow() throws IOException
		{
		 ReportEvents.CaptureScreenShots("true", "true");
		ReportEvents.CaptureScreenShots("true","false");
			//ReportGenerator.Generate("true");
		}
			
	 
	private void driver(DataReader datareader) throws Exception
	{
		page.SetCurrentPage("homepage");
		
		String browser[] = datareader.browser();
		commondata = datareader.getCommomData();

		for(int i=0;i<datareader.noOfTimes();i++)
		{
			testdata = datareader.getTestData(i);
			
			for(int j=0;j<datareader.noOfBrowsers();j++)
			{
				
				//Call methods
				open_browser(browser[j],datareader.getURL());
				//login();
				close_browser();
			}
		}
		// ReportGenerator.Generate("true");
	}
	private void open_browser(String browserType, String url) throws Exception
	{
		browser.InitiateBrowser(browserType);
		browser.Maximize();
		browser.NavigateURL(url);
	}
	private void login() throws Exception
	{
		page.SetCurrentPage("HomePage");
		new TextBox(browser,"userid").SendKeys(testdata.get("AccessID"));
		System.out.println(commondata.get("Hi"));
		System.out.println(commondata.get("AccessID"));
		System.out.println(commondata.get("Name"));
		page.Wait(3);
		new TextBox(browser,"Password").SendKeys(testdata.get("Password"));
		page.Wait(3);
		new Button(browser,"Submit").Click();
		System.out.println(commondata.get("Hi"));
		
		page.Wait(3);
		page.ScrollByPixel(0, 1000);
		//ReportEvents.Reporter("True", "Test Case Pass", "Test Case is passed.");
		
	}
	private void close_browser() throws Exception
	{
		
	}

	
}
}
