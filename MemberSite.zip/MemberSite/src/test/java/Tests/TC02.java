package Tests;

//import framework_web.*;
import FrameworkSource.web.*;
//import UserDefinedFunctions.GRS.*;
//import framework_global.*;
import FrameworkSource.global.*;
//import framework_global.reporter.*;
//import FrameworkSource.global.reporter.Logger;
//import FrameworkSource.global.reporter.ReportEvents;
//import FrameworkSource.global.reporter.ReportGenerator;

import java.io.File;
import org.junit.*;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;

import FrameworkSource.global.reporter.ReportEvents;
import FrameworkSource.global.reporter.ReportGenerator;
import UserDefinedFunctions.GRS.MemberSiteFL;

public class TC02 {
	
	@Test
	public void main() throws Exception
	{
    DataReader datareader = new DataReader("TC02");
	new TC02().new TestFlow().driver(datareader);
	}
	
private class TestFlow {

    Browser browser = new Browser();
	Page page = new Page(browser);
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	 HashMap<String, String> testdata, commondata;
	MemberSiteFL udf = new MemberSiteFL();
	ReportEvents ReportEvent = new ReportEvents(browser);
	
	TestFlow(){
		ReportEvents.CaptureScreenShots("true","false");
	}

	//MemberSiteFL udf= new MemberSiteFL();

	private void driver(DataReader datareader) throws Exception
	{
		 String browser[] = datareader.browser();
		 commondata = datareader.getCommomData();
			
		for(int i=0;i<datareader.noOfTimes();i++)
		{
			testdata = datareader.getTestData(i);
			for(int j=0;j<datareader.noOfBrowsers();j++)
			{	
				try {
				open_browser(browser[j],datareader.getURL());
				close_popup();
				close_browser();
				}
				finally
				{
					 //ReportGenerator.Generate("true");
				}
			}
		}
	}
	
	
	private void open_browser(String browserType, String url) throws Exception
	{
		browser.InitiateBrowser(browserType);	
		browser.Maximize();
		browser.NavigateURL(url);
	    ReportEvents.Reporter("Pass", "TC02_Region", "TC02_region Element found");
	}
	
	private void close_popup() throws Exception
	{
		Thread.sleep(3000);
		page.SetCurrentPage("StageGlobal");
		ReportEvents.Reporter("Pass", "CloseButton", "CloseButton clicked");
		new Button(browser,"CloseButton").Click();
		Thread.sleep(5000);
	}
	
	private void close_browser() throws Exception
	{
	   udf.close(browser);
		//browser.Quit();
	}
	
}

}
