package Tests;

import framework_web.*;
//import FrameworkSource.web.*;
import framework_global.*;
//import FrameworkSource.global.*;
import framework_global.reporter.*;
//import FrameworkSource.global.reporter.*;
import org.junit.*;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;
import java.util.HashMap;

public class TestFrames {

	@Test
	public void main() throws Exception
	{
	DataReader datareader = new DataReader("Name");
	new TestFrames().new TestFlow().driver(datareader);
	}

private class TestFlow {

	Browser browser = new Browser();
	Page page = new Page(browser);
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	HashMap<String, String> testdata, commondata;
	 HashMap<String, String> testdata, commondata;


	private void driver(DataReader datareader) throws Exception
	{
		String browser[] = datareader.browser();
		commondata = datareader.getCommomData();

		for(int i=0;i<datareader.noOfTimes();i++)
		{
			testdata = datareader.getTestData(i);
			for(int j=0;j<datareader.noOfBrowsers();j++)
			{
				
				//Call methods
				open_browser(browser[j],datareader.getURL());
				close_browser();
			}
		}
	}
	private void open_browser(String browserType, String url) throws Exception
	{
		browser.InitiateBrowser(browserType);
		browser.Maximize();
		browser.NavigateURL(url);
	}

	private void close_browser() throws Exception
	{
		browser.Quit();
	}

}
}
