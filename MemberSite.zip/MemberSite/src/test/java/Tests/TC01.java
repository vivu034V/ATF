package Tests.Class1;

//import framework_web.*;
import FrameworkSource.web.*;
import UserDefinedFunctions.UserDefinedfunctions;
//import framework_global.*;
import FrameworkSource.global.*;
//import framework_global.reporter.*;
import FrameworkSource.global.reporter.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.junit.*;
import java.util.HashMap;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;

public class GB_MemberSearch {

	@Test
	public void main() throws Exception
	{
	DataReader datareader = new DataReader("GB_MemberSearch");
	new GB_MemberSearch().new TestFlow().driver(datareader);
	}

private class TestFlow {

	

	Browser browser = new Browser();
	Page page = new Page(browser);
	HashMap<String, String> testdata, commondata;
	//ReportEvents ReportEvent = new ReportEvents(browser);
	
	TestFlow() throws IOException
	{
		ReportEvents.CaptureScreenShots("true","true");
	}

	UserDefinedfunctions udf =new UserDefinedfunctions(browser);

	private void driver(DataReader datareader) throws Exception
	{
		String browser1[] = datareader.browser();
		commondata = datareader.getCommomData();

		for(int i=0;i<datareader.noOfTimes();i++)
		{
		testdata = datareader.getTestData(i);
			for(int j=0;j<datareader.noOfBrowsers();j++)
			{				
				
				try
				{
				//Call methods
//				Runtime.getRuntime().exec("taskkill /F /IM chrome.exe");
				open_browser(browser1[j],datareader.getURL());
				udf.login([0],[1]);
				ParenWindow(browser1[j]);
			/*	ClickSerach([2]);								
				ClickNewSR_btn(); //Verify Alerts
				VerifySpecialInstructions();
				Click_Plan_Dtl();
				UpdateAddress([3]);
				Update_ClassificationColumn([4],[5],[6]);
				Change_Status();
				Logout();*/
				close_browser();
				}
				finally
				{
					close_browser();
					ReportGenerator.Generate("true");
					
				}
				
											
			}
		
			
		}
	}

	
	private void open_browser(String browserType, String url) throws Exception
	{
		/*if (browserType.equalsIgnoreCase("ie"))
		{
			Runtime.getRuntime().exec("taskkill /F /IM iexplore.exe");
		
		}*/
		
		browser.InitiateBrowser(browserType);
		browser.Maximize();
		browser.NavigateURL(url);
		ReportEvents.Reporter("Pass", "open_browser", "Browser is Initiated");

	
	}
			
	private void ParenWindow(String currentBrowser) throws IOException, InterruptedException
	{
		if(currentBrowser.equalsIgnoreCase("ie"))
		{
		page.Wait(15);
		browser.GetBrowser(1);	
		browser.GetBrowser("Siebel Financial Services");
		new WebElement(browser,"hompageclick").MouseClick("left");
		}
		else if(currentBrowser.equalsIgnoreCase("chrome"))
		{
			page.Wait(5);
			browser.GetBrowser(1);				
			browser.GetBrowser("Siebel Financial Services");
			
		}
		else if(currentBrowser.equalsIgnoreCase("firefox"))
		{
			
			page.Wait(10);
			if (new Dialog(browser).Exists())
				new Dialog(browser).Close();
						
			browser.GetBrowser(1);
			
			System.out.println(browser.driver.getCurrentUrl());
			
			//browser.GetBrowser("Siebel Financial Services");
			
		}
		
		ReportEvents.Reporter("Pass", "ParenWindow", "Parent Window Handled Successfully");

		
	}
	//Search for the contact by clicking on the binocular search button and search Access ID

	private void ClickSerach(String accessId) throws IOException, InterruptedException
	{
		page.SetCurrentPage("HomePage");			
		browser.GetBrowser(1);
		page.Wait(3);
		new Button(browser,"Search_BinocularBtn").Click();
		page.Wait(2);
		new TextBox(browser,"AccessId").SendKeys(accessId);
		new Button(browser,"AccessId_SearchBtn").Click();
		
	/*	if(new Dialog(browser).Exists())
		{
		new Dialog(browser).Click();
		new Button(browser,"AccessId_SearchBtn").Click();
		}*/
		
		//Verify Member Summary Selected
		page.Wait(2);
		String s = new Label(browser,"MemberSummary").AttributeValue("aria-selected");
		Assert.assertTrue("Member Summary not selected",s.equalsIgnoreCase("true"));
		ReportEvents.Reporter("Pass", "ClickSerach", "Serach Icon CLicked");
		
	}
	
	//CLick on NewSR Button and  Verify 10 Alerts
	private void ClickNewSR_btn() throws IOException, InterruptedException
	{
		page.Wait(5);
		Assert.assertTrue("New Sr Button Not exists", new Button(browser,"NewSR_Btn").Exists());	
		new Button(browser,"NewSR_Btn").Highlight();
		new Button(browser,"NewSR_Btn").Click();
				
		page.Wait(2);
		if(new Dialog(browser).GetVisibleText().contains("GOLD QUEUE"));
		new Dialog(browser).Click();
		
		page.Wait(1);
		if(new Dialog(browser).GetVisibleText().contains("EMPLOYEE/DEPENDENT UPDATES"))
		new Dialog(browser).Click();
		
		page.Wait(1);;
		if(new Dialog(browser).GetVisibleText().contains("This is a test"))
		new Dialog(browser).Click();
		
		page.Wait(1);;
		if(new Dialog(browser).GetVisibleText().contains("another test"))
		new Dialog(browser).Click();
		
		page.Wait(1);;
		if(new Dialog(browser).GetVisibleText().contains("WELLNESS ASSESSMENT"))
		new Dialog(browser).Click();
		
		page.Wait(1);;
		if(new Dialog(browser).GetVisibleText().contains("RETIREES"))
		new Dialog(browser).Click();
		
		page.Wait(1);;
		if(new Dialog(browser).GetVisibleText().contains("DRX00 in Ontario"))
		new Dialog(browser).Click();
		
		page.Wait(1);;
		if(new Dialog(browser).GetVisibleText().contains("VISION"))
		new Dialog(browser).Click();
		
		page.Wait(1);;
		if(new Dialog(browser).GetVisibleText().contains("COB FREEZE"))
		new Dialog(browser).Click();
		
		page.Wait(1);;
		if(new Dialog(browser).GetVisibleText().contains("PDD CARDS"))
		new Dialog(browser).Click();
		
		page.Wait(1);;	
		ReportEvents.Reporter("Pass", "VerifyAlerts", "10 AlertsVerified");
		
	}
	
	// 
	private void VerifySpecialInstructions() throws InterruptedException, IOException
	{
		
		//Verify Member Coverage view
		page.Wait(2);
		String member = new Label(browser,"MemberCoverage").AttributeValue("aria-selected");
		Assert.assertTrue("Member Coverage not selected",member.equalsIgnoreCase("true"));
				
		//No Records Displayed
		String label_Norecords = new Label(browser,"VerifyNoRecords").GetValue();
		System.out.print("no rec="+label_Norecords);
		Assert.assertTrue("NoRecords not Displayed" , label_Norecords.equals("No Records"));
		ReportEvents.Reporter("Pass", "VerifySpecialInstructions", "Special Instructions Verified");
		
	}
	
	//Click on PanDtl Button and Verify Planid 01 is Displayed
	private void Click_Plan_Dtl() throws IOException, InterruptedException
	{
		page.Wait(1);
		Assert.assertTrue("PlanDTl Button exits on the Page",new Button(browser,"PlanDtl_Btn").Exists());
		new Button(browser,"PlanDtl_Btn").Highlight();
		new Button(browser,"PlanDtl_Btn").Click();
		new TextBox(browser,"Planid_1").Highlight();
		page.Wait(2);
		Assert.assertEquals("Unexpected String displayed", "01", new TextBox(browser,"Planid_1").AttributeValue("value"));
		
		String positve_enrl_text = new TextBox(browser,"PossitiveEnrolment_Value").AttributeValue("value");
		Assert.assertEquals("Unexpected String displayed", "Y-Yes, there is positive enrollment", positve_enrl_text);
		ReportEvents.Reporter("Pass", "Click_Plan_Dtl", "Clicked on Plan_Dtl");
	}
	
	// Update the Address
	
	private void UpdateAddress(String addrLine1) throws IOException, InterruptedException
	{
		//Select Address tab
	  //  page.ScrollTillEnd();
		page.Wait(2);
		new HyperLink(browser,"ClickAddressTab").Click();
		page.Wait(10);
		
		browser.driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
		//new TextBox(browser,"AddressLine1").WaitForElementClick();
		new TextBox(browser,"AddressLine1").Click();
		new TextBox(browser,"AddressLine1").Clear();
		new TextBox(browser,"AddressLine1").SendKeys(addrLine1);
		
		Assert.assertTrue("Notify GRS is not Selected", new DropDown(browser,"NotifyGRS").IsSelected());
		page.Wait(1);
		new Button(browser,"Make_AddresssChange").Click();
		//Address change message
		page.Wait(1);
		if(new Dialog(browser).GetVisibleText().contains("address change"))
		new Dialog(browser).Click();
		
		ReportEvents.Reporter("Pass", "UpdateAddress", "Address Updated");
		
	}
	
	// Update Classification Fields
	
	private void Update_ClassificationColumn(String callType, String callSubtype,String callInquiry) throws InterruptedException, IOException 
	{
		page.Wait(1);
		new DropDown(browser,"CallClassification_CallType_txt").Click();
		new DropDown(browser,"CallClassification_CallType_list").Click();		
		new TextBox(browser,"CallClassification_CallType_txt").SendKeys(callType.trim());
		new TextBox(browser,"CallClassification_CallType_txt").PressKey("Enter", 1);
		page.Wait(1);
			  
		new DropDown(browser,"CallClassification_CallSubType_txt").Click();
		new DropDown(browser,"CallClassification_CallSubType_list").Click();
		new TextBox(browser,"CallClassification_CallSubType_txt").SendKeys(callSubtype.trim());
		new TextBox(browser,"CallClassification_CallSubType_txt").PressKey("Enter", 1);
		
		new DropDown(browser,"CallClassification_Call Inquiry_txt").Click();
		new DropDown(browser,"CallClassification_Call Inquiry_list").Click();
		new TextBox(browser,"CallClassification_Call Inquiry_txt").SendKeys(callInquiry.trim());
		new TextBox(browser,"CallClassification_Call Inquiry_txt").PressKey("Enter", 1);
		
		ReportEvents.Reporter("Pass", "Update_ClassificationColumn", "Update_ClassificationColumn Updated");
		
	}
	
	//Update Error Type and Status
	
	private void Change_Status() throws IOException, InterruptedException
	{
		//Error Type
		page.Wait(2);
		new TextBox(browser,"ErrorType").SendKeys("No Error");
		new TextBox(browser,"ErrorType").PressKey("Enter",1);
		
		page.Wait(2);
		new TextBox(browser,"SR_Status").Click();
		if(!new TextBox(browser,"SR_Status").AttributeValue("value").isEmpty());
		{
			new TextBox(browser,"SR_Status").PressKey("Backspace", 12);
		}
		new TextBox(browser,"SR_Status").SendKeys("Closed");
		new TextBox(browser,"SR_Status").PressKey("Enter",1);
		System.out.println(new TextBox(browser,"SR_Status").AttributeValue("value"));
		
		ReportEvents.Reporter("Pass", "Change_Status", "Change_Status Updated to closed");
		
	}
	
	//Logout
	private void Logout() throws IOException, InterruptedException
	{
		page.Wait(3);
		new HyperLink(browser,"ClickFile").Click();
		page.Wait(2);
		Assert.assertTrue("Logout Btn Not Exists", new HyperLink(browser,"Click_Logout").Exists());
		new HyperLink(browser,"Click_Logout").Highlight();
		page.Wait(1);	
		new HyperLink(browser,"Click_Logout").Click();
		ReportEvents.Reporter("Pass", "Logout", "Logout Link CLicked");
	}
	
	

	private void close_browser() throws Exception
	{
		browser.Quit();
	}

}
}
