package TestSuite;

import org.junit.*;
import org.junit.experimental.ParallelComputer;
import org.junit.runner.JUnitCore;
import FrameworkSource.global.*;
import FrameworkSource.global.almbridge.ALMBridge;
//import framework_global.*;
import FrameworkSource.global.reporter.*;
import Tests.*;
import Tests.French.*;

public class TestSuite {

	@Test
	public void test() throws Exception {
		

		 //Class[] cls = {TC01_FR.class,TC01.class};
		 //Class[] cls = {TC03.class};
		Class[] cls= ExecutionController.ExecutionController();
		
		//ReportEvents.ScreenShotPriority("testcase");
		//ReportEvents.CaptureScreenshots(True, FrameworkScreenshots, Priority);
		 
		//ReportEvents.ScreenShotRequired("false");
		
		//ReportEvents.StepScreenShotRequired("true");
		
		
		
		//Run tests serially			 
		//JUnitCore.runClasses(ParallelComputer.methods(), cls);
		
		//Run tests parallel
		JUnitCore.runClasses(ParallelComputer.classes(), cls);
		
		 //ReportGenerator.Generate("true");
		 
		ALMBridge.SendStatus("true");
		
	}

}
