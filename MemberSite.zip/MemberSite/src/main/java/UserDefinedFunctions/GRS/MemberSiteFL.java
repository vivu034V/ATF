package UserDefinedFunctions.GRS;

//import framework_web.*;
import FrameworkSource.web.*;
//import framework_web.Browser;


public class MemberSiteFL {
	//Close all browser tabs
	public void close(Browser browser) throws Exception
	{
		browser.Quit();
	}
	

}
