package FrameworkSource.web;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import FrameworkSource.global.reporter.*;

/**
 * The class consists of all the customized functions related to browsers.
 */
public class Browser {
	
	public  WebDriver driver = null;
	public  String[][] PageValues = null;	
	public  int rowCount = 0;
	public  int columnCount = 0;
	public  String[] FoundValue = null;
	public  WebElement element;
	
/**
* This function launches a browser version either Chrome, IE or Firefox.
* @param BrowserType is a string parameter which takes either values of Chrome, IE or Firefox.
* @throws InterruptedException
 * @throws IOException 
*/
public void InitiateBrowser(String BrowserType) throws InterruptedException, IOException
	{	
	String callerClassName = new Exception().getStackTrace()[1].getMethodName();
		try{
			
			
			switch(BrowserType.toLowerCase())
			{
				case "chrome":
				System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"\\src\\test\\resources\\browserdrivers\\chromedriver.exe");
				driver = new ChromeDriver(); 
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				ReportEvents.Done(callerClassName+":Browser", "Google Chrome is Launched : "+ driver);
				//Logger.INFO("Browser", "Google Chrome is Launched : "+ driver);	
				break;
				
				case "ie":
				File ieFile = new File(System.getProperty("user.dir")+"\\src\\test\\resources\\browserdrivers\\IEDriverServer.exe");
				System.setProperty("webdriver.ie.driver", ieFile.getAbsolutePath());
				DesiredCapabilities ieCapabilities = DesiredCapabilities.internetExplorer();
				ieCapabilities.setCapability("ignoreZoomSetting", true);
				ieCapabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS,
						true);
				ieCapabilities.setCapability(InternetExplorerDriver.INITIAL_BROWSER_URL, " ");
				driver = new InternetExplorerDriver(ieCapabilities);
				//driver = new InternetExplorerDriver(ieCaps);
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				ReportEvents.Done(callerClassName+":Browser", "IE is Launched : "+ driver);
				//Logger.INFO("Browser", "IE is Launched : "+ driver);	
				break;
				
				case "firefox":
				System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir")+"\\src\\test\\resources\\browserdrivers\\geckodriver.exe");
				driver = new FirefoxDriver(); 
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				ReportEvents.Done(callerClassName+":Browser", "Firefox is Launched : "+ driver);
				//Logger.INFO("Browser", "Firefox is Launched : "+ driver);	
				break;
				
				default: 
					driver=null;
					ReportEvents.Done(callerClassName+":Browser", "Invalid browser name : "+ BrowserType);
					//Logger.INFO("Browser", "Invalid browser name : "+ BrowserType);	
			}
		
		}
		
		catch(Exception e)
		{
			ReportEvents.Error(callerClassName+":Browser", e);
			//Logger.ERROR("Browser",e);
		     Assert.fail();
			}
		
	}
/**
 * The function opens a URL in the launched browser.
 * @param url takes a String value.
 * @throws IOException 
 */
	public void NavigateURL(String url) throws IOException
	{
		String callerClassName = new Exception().getStackTrace()[1].getMethodName();
		try{
		driver.get(url);
		ReportEvents.Done(callerClassName+":Browser", "Opening URL "+ url);
		//Logger.INFO("Browser","Opening URL "+ url);
		}
		catch(Exception e)
		{
			ReportEvents.Error(callerClassName+":Browser", e);
			//Logger.ERROR("Browser",e);
		     Assert.fail();
		}
		
	}
	/**
	 * The function closes the open browser.
	 * @throws IOException 
	 */
	public void Quit() throws IOException
	{
		String callerClassName = new Exception().getStackTrace()[1].getMethodName();
		try{
			driver.quit();
			ReportEvents.Done(callerClassName+":Browser",  "Browser is Closed");
			//Logger.INFO("Browser", "Browser is Closed");	
		}
		catch(Exception e)
		{
			ReportEvents.Error(callerClassName+":Browser", e);
			//Logger.ERROR("Browser",e);
		     Assert.fail();
		}
	}
	/**
	 * The function Maximizes the browser.
	 * @throws IOException 
	 */
	public void Maximize() throws IOException
	{
		String callerClassName = new Exception().getStackTrace()[1].getMethodName();
		try{
		driver.manage().window().maximize();
		ReportEvents.Done(callerClassName+":Browser",  "Browser Maximize");
		//Logger.INFO("Browser", "Browser Maximize");
		}
		catch(Exception e)
		{
			ReportEvents.Error(callerClassName+":Browser", e);
			//Logger.ERROR("Browser",e);
		     Assert.fail();
		}
		
	}
	/**
	 * The function switches to desired open windows of browser.
	 * @param windownumber takes integer value. Eg.1 for first window, 2 for second window
	 * @throws IOException 
	 */
	public void GetBrowser(int windownumber) throws IOException
	{
		String callerClassName = new Exception().getStackTrace()[1].getMethodName();
		try{
		ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
		System.out.println(tabs.size());
		ReportEvents.Done(callerClassName+":Browser",  "Total No. of windows opened" + tabs.size());
		//Logger.INFO("Browser", "Total No. of windows opened" + tabs.size());
		driver.switchTo().window((String) tabs.get(windownumber-1));
		ReportEvents.Done(callerClassName+":Browser",  "Windows switched successfully");
		//Logger.INFO("Browser", "Windows switched successfully");
		}
		catch(Exception e)
		{
			ReportEvents.Error(callerClassName+":Browser", e);
			//Logger.ERROR("Browser",e);
		     Assert.fail();
		}

	}
	
	/**
	 * The function switches to desired open windows of browser.
	 * @param title takes the current page title.
	 * @throws IOException 
	 */
	public void GetBrowser(String title) throws IOException
	{
		String callerClassName = new Exception().getStackTrace()[1].getMethodName();
		try{
			ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
			System.out.println(tabs.size());
			ReportEvents.Done(callerClassName+":Browser",  "Total No. of windows opened" + tabs.size());
			//Logger.INFO("Browser", "Total No. of windows opened" + tabs.size());
			String currentWindow = driver.getWindowHandle();  //will keep current window to switch back
			for(String winHandle : driver.getWindowHandles()){
			   if (driver.switchTo().window(winHandle).getTitle().equals(title)) {
				   ReportEvents.Done(callerClassName+":Browser",  "Windows switched successfully");
					//Logger.INFO("Browser", "Windows switched successfully");
			     break;
			   } 
			   else {
			      driver.switchTo().window(currentWindow);
			   } 
			}
		}
		catch(Exception e)
		{
			ReportEvents.Error(callerClassName+":Browser", e);
			//Logger.ERROR("Browser",e);
		     Assert.fail();
		}

	}
	
	/**
	 * The function clicks Back button of opened browser.
	 * @throws IOException 
	 */
	public  void Back() throws IOException
	{
		String callerClassName = new Exception().getStackTrace()[1].getMethodName();
		try{
		driver.navigate().back();
		ReportEvents.Done(callerClassName+":Browser",  "Browser Back button is pressed successfully. ");
		//Logger.INFO("Browser", "Browser Back button is pressed successfully. ");	
	}
		catch(Exception e)
		{
			ReportEvents.Error(callerClassName+":Browser", e);
			//Logger.ERROR("Browser",e);
		     Assert.fail();
		}
	}
	/**
	 * The function clicks on the Forward button of opened browser.
	 * @throws IOException 
	 */
	public  void Forward() throws IOException
	{
		String callerClassName = new Exception().getStackTrace()[1].getMethodName();
		try{
		driver.navigate().forward();
		ReportEvents.Done(callerClassName+":Browser",  "Browser Forward button is pressed successfully. ");
		//Logger.INFO("Browser", "Browser Forward button is pressed successfully. ");
		}
		catch(Exception e)
		{
			ReportEvents.Error(callerClassName+":Browser", e);
			//Logger.ERROR("Browser",e);
		     Assert.fail();
		}
		
	}
	/**
	 * The function clears all cookies of the browser.
	 * @throws IOException 
	 */
	public void ClearCookies() throws IOException
	{
		String callerClassName = new Exception().getStackTrace()[1].getMethodName();
		try{
		driver.manage().deleteAllCookies();
		ReportEvents.Done(callerClassName+":Browser",  "All Cookies has been deleted successfully. ");
		//Logger.INFO("Browser", "All Cookies has been deleted successfully. ");
		}
		catch(Exception e)
		{
			ReportEvents.Error(callerClassName+":Browser", e);
			//Logger.ERROR("Browser",e);
		     Assert.fail();
		}
	}
	
	/**
	 * The function clears specific cookie by name.
	 * @throws IOException 
	 */
	public void ClearCookies(String name) throws IOException
	{
		String callerClassName = new Exception().getStackTrace()[1].getMethodName();
		try{
		driver.manage().deleteCookieNamed(name);
		ReportEvents.Done(callerClassName+":Browser",  name+" cookie has been deleted successfully. ");
		//Logger.INFO("Browser", name+" cookie has been deleted successfully. ");
		}
		catch(Exception e)
		{
			ReportEvents.Error(callerClassName+":Browser", e);
			//Logger.ERROR("Browser",e);
		     Assert.fail();
		}
	}
	
	
	/**
	 * The function refresh the opened open session of browser.
	 * @throws IOException 
	 */
	public void Refresh() throws IOException
	{
		String callerClassName = new Exception().getStackTrace()[1].getMethodName();
		try{
		driver.navigate().refresh();
		ReportEvents.Done(callerClassName+":Browser",   "Browser Page Refresh successfully.");
		//Logger.INFO("Browser", "Browser Page Refresh successfully.");
		}
		catch(Exception e)
		{
			ReportEvents.Error(callerClassName+":Browser", e);
			//Logger.ERROR("Browser",e);
		     Assert.fail();
		}
	}
	
	/**
	 * The function will kill any task.
	 * @throws IOException 
	 */	
	public void KillTask(String taskName) throws IOException
	{
		String callerClassName = new Exception().getStackTrace()[1].getMethodName();
		if(!taskName.contains(".exe"))
		{
			taskName = taskName + ".exe"; 
		}

		try{
		Runtime.getRuntime().exec("Taskkill /IM "+taskName+" /F");
		ReportEvents.Done(callerClassName+":Browser",   taskName+" killed successfully.");
		//Logger.INFO("Browser", "Browser Page Refresh successfully.");
		}
		catch(Exception e)
		{
			ReportEvents.Error(callerClassName+":Browser", e);
			//Logger.ERROR("Browser",e);
		     Assert.fail();
		}
	}
	
}