package FrameworkSource.web;

import FrameworkSource.global.*;
import FrameworkSource.global.reporter.*;

import java.io.IOException;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WebUIElement {
	
	Browser b;
	/**
	 * WebUIElement class constructor, directly invoked when an object of WebUIElement class is created. Constructor calls FindExactvalue function in ORReader class.
	 * Webelementlocation function is also invoked which returns an element value.
	 * @param b is a static global variable in Browser class which maintains properties of open browser session.
	 * @param Elementvalue takes a string value.
	 */
	public WebUIElement(Browser b,String Elementvalue)
	{	
		
		String ClassName = new Exception().getStackTrace()[2].getMethodName();
    
		try{
		 this.b = b;
		 boolean ElementProperty = new ORReader(b).FindProperty(Elementvalue);
		 if (ElementProperty == true)
		 {
		 b.FoundValue=new ORReader(b).FindExactvalue(Elementvalue);
		 System.out.println(b.FoundValue[0]);
		 ReportEvents.Done(ClassName+":ElementValue", "Property Values returned from Properties.xlsx: " + b.FoundValue[0] + " & "+ b.FoundValue[1]);
		// Logger.INFO(ClassName, "Property Values returned from Properties.xlsx: " + b.FoundValue[0] + " & "+ b.FoundValue[1]);
		 b.element= Webelementlocation();
		 }
		 else
		 {
			 ReportEvents.Fatal(ClassName+":ElementValue", "Element '"+ Elementvalue +"' Not Exists in the Properties Excel sheet");
			// Logger.INFO("Element","Element '"+ Elementvalue +"' Not Exists in the Properties Excel sheet");
			 b.element = null; //Setting element to null as if user calls function like exists. Then this function will perform operation on previous b.elment
		 }
		}
		catch(Exception e)
		{
			//Logger.ERROR(ClassName, e);
			b.element = null; //Setting element to null as if user calls function like exists. Then this function will perform operation on previous b.elment
		}
	}
	
	/**
	 * Single parameterized constructor of WebUiElement
	 * @param Browser type
	 */
	public WebUIElement(Browser b)
	{
		this.b = b;
	}
	
	/**
	 * The function searches the element present on the web page depending upon various parameters.
	 * @return WebElement type
	 */
	public WebElement Webelementlocation()
	{
		String Property = b.FoundValue[0];
		String PropertyValue = b.FoundValue[1];
		WebElement element = null;
		String id ="id";
		String xpath ="xpath";
		//String name ="name";
		String classname ="class";
		String linktext= "linkText";
		String partiallink="partialLinkText";
		String cssSelector="cssSelector";
		String name="name";

		if(Property.equalsIgnoreCase(id))
		{
			element =(new WebDriverWait(b.driver, 10))
					.until(ExpectedConditions.presenceOfElementLocated(By.id(PropertyValue)));		
		}
		
		else if(Property.equalsIgnoreCase(xpath))
		{
			element =(new WebDriverWait(b.driver, 10))
					.until(ExpectedConditions.presenceOfElementLocated(By.xpath(PropertyValue)));
		}
		else if(Property.equalsIgnoreCase(classname))
		{
			element =(new WebDriverWait(b.driver, 10))
					.until(ExpectedConditions.presenceOfElementLocated(By.className(PropertyValue)));
		}
		else if(Property.equalsIgnoreCase(linktext))
		{
			element =(new WebDriverWait(b.driver, 10))
					.until(ExpectedConditions.presenceOfElementLocated(By.linkText(PropertyValue)));
		}
		else if(Property.equalsIgnoreCase(partiallink))
		{
			element =(new WebDriverWait(b.driver, 10))
					.until(ExpectedConditions.presenceOfElementLocated(By.partialLinkText(PropertyValue)));
		}
		else if(Property.equalsIgnoreCase(partiallink))
		{
			element =(new WebDriverWait(b.driver, 10))
					.until(ExpectedConditions.presenceOfElementLocated(By.partialLinkText(PropertyValue)));
		}
		else if(Property.equalsIgnoreCase(cssSelector))
		{
			element =(new WebDriverWait(b.driver, 10))
					.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector(PropertyValue)));
		}
		
		else if(Property.equalsIgnoreCase(name))
		{
			element =(new WebDriverWait(b.driver, 10))
					.until(ExpectedConditions.presenceOfElementLocated(By.name(PropertyValue)));		
		}
		return element;
	}
	/**
	 * The function clicks on the web element.
	 * @throws IOException 
	 */
	public void Click() throws IOException
	{
		String callerClassName = new Exception().getStackTrace()[1].getMethodName();
		try{
		b.element.click();
		ReportEvents.Done(callerClassName+":WebUIElement", "Element: "+b.element+ "is clicked successfully.",b);
		}
		catch(Exception e)
		{
		 ReportEvents.Error(callerClassName+":WebUIElement",e,b);
	     Assert.fail();
		}
	}
	
	/**
	 * The function verifies different message labels being displayed.
	 * @param value takes an String value to be verified.
	 * @return boolean value. Returns True if the message is same and False if not.
	 * @throws IOException 
	 */
	public boolean VerifyMessage(String exp_message) throws IOException
	{		
		String callerClassName = new Exception().getStackTrace()[1].getMethodName();
		boolean flag = false;		
		try	{				
		String actualmessage = b.element.getText();
		if(exp_message.equals(actualmessage))
		{	flag= true;
		ReportEvents.Done(callerClassName+":WebUIElement", "Message "+ exp_message + "is displayed.",b);
			//Logger.INFO(ClassName, "Message "+ exp_message + "is displayed.");
		}
		else{flag=false;
		ReportEvents.Done(callerClassName+":WebUIElement", "Message "+ exp_message + "is not displayed.",b);
			//Logger.INFO(ClassName, "Message "+ exp_message + "is not displayed.");
		}
		}
		catch(Exception e)
		{
			flag=false;
			ReportEvents.Error(callerClassName+":WebUIElement",e,b);
			//Logger.ERROR(ClassName,e);
		    Assert.fail();
		}
		return flag;				
	}
	
	/**
	 * The function checks on the existence of the web element.
	 * @return boolean value. Returns True if the element is found else false.
	 * @throws IOException 
	 */
	public boolean Exists() throws IOException
	{
		String callerClassName = new Exception().getStackTrace()[1].getMethodName();
		boolean flag = false;
		try{
			 if(b.element.isDisplayed()) 
			 {
				  flag= true;
				  ReportEvents.Done(callerClassName+":WebUIElement", "Element: "+b.element+ " exists.",b);
			    // Logger.INFO(ClassName,"Element: "+b.element+ " exists.");
			 }	  
			 else
			 	{
				  flag = false;
				  ReportEvents.Done(callerClassName+":WebUIElement", "Element: "+b.element+ " doesn't exists.",b);
				  //Logger.INFO(ClassName,"Element: "+b.element+ " doesn't exists.");
			 	}
				}
				catch(Exception e)
				{
					flag = false;
					ReportEvents.Done(callerClassName+":WebUIElement", "Element doesn't exists.");
					//Logger.ERROR(ClassName,e);
				    Assert.fail();
				}
		
		return flag;
	}
	
	/**
	 * The function will highlight a web element with red color rectangular box.
	 * @throws IOException 
	 */
	public void Highlight() throws IOException
	{
		String callerClassName = new Exception().getStackTrace()[1].getMethodName();
		
		if (b.driver instanceof JavascriptExecutor) {
	        ((JavascriptExecutor)b.driver).executeScript("arguments[0].style.border='3px solid red'", b.element);
	        ReportEvents.Done(callerClassName+":WebUIElement", "Element :"+b.element+" highlighted.",b);
			//Logger.INFO(ClassName,"Element :"+b.element+" highlighted.");
	    }
		
	}
	//		int total = Integer.parseInt(seconds+"000");
	//Thread.sleep(total);
	/**
	 * The function will highlight a web element with red color rectangular box for specified seconds.
	 * @param seconds accept integer values.
	 * @throws InterruptedException 
	 * @throws IOException 
	 */
	public void Highlight(int seconds) throws InterruptedException, IOException
	{
		String callerClassName = new Exception().getStackTrace()[1].getMethodName();
		int total = Integer.parseInt(seconds+"000");
		
		if (b.driver instanceof JavascriptExecutor) {
	        ((JavascriptExecutor)b.driver).executeScript("arguments[0].style.border='3px solid red'", b.element);
			Thread.sleep(total);
	        ((JavascriptExecutor)b.driver).executeScript("arguments[0].setAttribute('style',arguments[0])", b.element);
	        ReportEvents.Done(callerClassName+":WebUIElement", "Element :"+b.element+" successfully highlighted for "+seconds+" seconds.",b);
	    }
		
	}
	
	/**
	 * The function determines if an element is selected or not.
	 * It is widely used on check boxes, radio buttons and options in a select. 
	 * @return returns true if the element is selected and false if it is not.
	 * @throws IOException 
	 */
	public boolean IsSelected() throws IOException
	{	
		String callerClassName = new Exception().getStackTrace()[1].getMethodName();
		boolean flag = false;
		try{
			 if(b.element.isSelected()) 
			 {
				  flag= true;
				  ReportEvents.Done(callerClassName+":WebUIElement", "Element: "+b.element+ " is selected.",b);
			    // Logger.INFO(ClassName,"Element: "+b.element+ " exists.");
			 }	  
			 else
			 	{
				  flag = false;
				  ReportEvents.Done(callerClassName+":WebUIElement", "Element: "+b.element+ " is not selected.",b);
				  //Logger.INFO(ClassName,"Element: "+b.element+ " doesn't exists.");
			 	}
				}
				catch(Exception e)
				{
					flag = false;
					ReportEvents.Fatal("WebUIElement", "Element doesn't exists so cannot perform IsSelected operation");
					//Logger.ERROR(ClassName,e);
				    Assert.fail();
				}
		
		return flag;
		
		
		
		
	}
	
	/**
	 * The function determines if an element is enabled or not. 	
	 * @return returns true if element is enabled and false if not.
	 * @throws IOException 
	 */
	public boolean IsEnabled() throws IOException
	{
		String callerClassName = new Exception().getStackTrace()[1].getMethodName();
		boolean flag = false;
		try{
			 if(b.element.isEnabled()) 
			 {
				  flag= true;
				  ReportEvents.Done(callerClassName+":WebUIElement", "Element: "+b.element+ " is enabled.",b);
			    // Logger.INFO(ClassName,"Element: "+b.element+ " exists.");
			 }	  
			 else
			 	{
				  flag = false;
				  ReportEvents.Done(callerClassName+":WebUIElement", "Element: "+b.element+ " is not enabled.",b);
				  //Logger.INFO(ClassName,"Element: "+b.element+ " doesn't exists.");
			 	}
				}
				catch(Exception e)
				{
					flag = false;
					ReportEvents.Fatal("WebUIElement", "Element doesn't exists so cannot perform IsEnabled operation");
					//Logger.ERROR(ClassName,e);
				    Assert.fail();
				}
		
		return flag;
		}
	
	/**
	 * The function determines if an element is displayed or not. 	
	 * @return returns true if element is displayed and false if not.
	 * @throws IOException 
	 */
	public boolean IsDisplayed() throws IOException
	{
		String callerClassName = new Exception().getStackTrace()[1].getMethodName();
		boolean flag = false;
		try{
			 if(b.element.isDisplayed()) 
			 {
				  flag= true;
				  ReportEvents.Done(callerClassName+":WebUIElement", "Element: "+b.element+ " is displayed.",b);
			    // Logger.INFO(ClassName,"Element: "+b.element+ " exists.");
			 }	  
			 else
			 	{
				  flag = false;
				  ReportEvents.Done(callerClassName+":WebUIElement", "Element: "+b.element+ " is not displayed.",b);
				  //Logger.INFO(ClassName,"Element: "+b.element+ " doesn't exists.");
			 	}
				}
				catch(Exception e)
				{
					flag = false;
					ReportEvents.Fatal("WebUIElement", "Element doesn't exists so cannot perform IsDisplayed operation");
					//Logger.ERROR(ClassName,e);
				    Assert.fail();
				}
		
		return flag;
	}
		
	/**
	 * The function hovers the mouse pointer to the specified element.
	 * @throws IOException 
	 */
	public void MouseHover() throws IOException
	{
		String callerClassName = new Exception().getStackTrace()[2].getMethodName();
		try{
		Actions Object = new Actions(b.driver);
		Object.moveToElement(b.element).build().perform();
		ReportEvents.Done(callerClassName+":WebUIElement", "Mouse Hover to "+ b.element+" done successfully.",b);
		//Logger.INFO(ClassName, "Mouse Hover to "+ b.element+" done successfully.");
		}
		catch(Exception e)
		{
			ReportEvents.Error(callerClassName+":WebUIElement",e,b);
	     //Logger.ERROR(ClassName,e);
	     Assert.fail();
		}
	}
	/**
	 * The function returns text value of the web element.
	 * @return String value.
	 * @throws IOException 
	 */
	public String GetValue() throws IOException
	{
		
		String callerClassName = new Exception().getStackTrace()[2].getMethodName();
		String text=null;
		try{
		text = b.element.getText();
		ReportEvents.Done(callerClassName+":WebUIElement",  "Text Value: "+b.element.getText()+ " found successfully." + b.element.getText(),b);
		}
		catch(Exception e)
		{
		 ReportEvents.Error(callerClassName+":WebUIElement",e,b);
	     Assert.fail();
		}
	return text;
		
	}
	/**
	 * The function returns the attribute value of the attribute.
	 * @param AttributeName takes string value.
	 * @return String Value.
	 * @throws IOException 
	 */
	
	public String AttributeValue(String AttributeName) throws IOException
	{		
		String callerClassName = new Exception().getStackTrace()[2].getMethodName();
		String attribute=null;
		try{
			attribute = b.element.getAttribute(AttributeName);
			ReportEvents.Done(callerClassName+":WebUIElement",  "Attribute Value Found successfully." + b.element.getAttribute(AttributeName),b);
		}
		catch(Exception e)
		{
		 ReportEvents.Error(callerClassName+":WebUIElement",e,b);
	     Assert.fail();
		}
	return attribute;
	}
	
	
	/**
	 * The function find out the dimension size of the image.
	 * @return Dimension size of the image.
	 */
	public Dimension Size()
	{
		return b.element.getSize();
	}
	
	/**
	 * The function find out the location of an element. Using object of Point we can find x and y coordinates of any element
	 * @return Point i.e location of the element.
	 */
	public Point Location()
	{
		return b.element.getLocation();
	}
	
	/**
	 * The function performs different clicks of Mouse. 
	 * @param type takes String value like Right, Double and Left.
	 * @throws IOException 
	 */
	public void MouseClick(String type) throws IOException
	{
		String callerClassName = new Exception().getStackTrace()[2].getMethodName();
		try{
			
		if(type.equalsIgnoreCase("Right"))
		{
			Actions action = new Actions(b.driver).contextClick(b.element);
	        action.build().perform();
	        ReportEvents.Done(callerClassName+":WebUIElement",  "Right Click is Pressed Successfully on element :" + b.element,b);
	       // Logger.INFO(ClassName, "Right Click is Pressed Successfully on element :" + b.element);
		}
		else if(type.equalsIgnoreCase("Double"))
	    	{
	    		Actions actions = new Actions(b.driver).contextClick(b.element);
	            actions.moveToElement(b.element).doubleClick().build().perform();
	            ReportEvents.Done(callerClassName+":WebUIElement",  "Double Click is Pressed Successfully on element :" + b.element,b);
	            //Logger.INFO(ClassName, "Double Click is Pressed Successfully on element :" + b.element);
	    	}
		else if(type.equalsIgnoreCase("Left"))
    	{
			Actions actions = new Actions(b.driver).contextClick(b.element);
			actions.moveToElement(b.element).click().build().perform();
    		ReportEvents.Done(callerClassName+":WebUIElement",  "Left Click is Pressed Successfully on element :" + b.element,b);
    		//Logger.INFO(ClassName, "Left Click is Pressed Successfully on element :" + b.element);
    	} 
		else
		{
    		ReportEvents.Fatal(callerClassName+":WebUIElement",  "Mouse");
    		System.out.println("Invalid");
		}
		}
		catch(Exception e)
		{
			ReportEvents.Error(callerClassName+":WebUIElement", e,b);
	    // Logger.ERROR(ClassName,e);
	     Assert.fail();
		}
	}
	/**
	 * The functions moved the mouse cursor to defined xoffset and yoffset.
	 * @param xOffset takes integer value.
	 * @param yOffset takes integer value.
	 * @throws IOException 
	 */
	public void MouseMoveTo(int xOffset, int yOffset) throws IOException
	{
		String callerClassName = new Exception().getStackTrace()[2].getMethodName();
		try{
		Actions builder = new Actions(b.driver);   
		builder.moveToElement(b.element, xOffset, yOffset).click().build().perform();
		ReportEvents.Done(callerClassName+":WebUIElement", "Mouse successfully moved to location: " + xOffset + yOffset,b);
		//Logger.INFO(ClassName,"Mouse successfully moved to location: " + xOffset + yOffset);
		}
		catch(Exception e)
		{
			ReportEvents.Error(callerClassName+":WebUIElement", e,b);
	     //Logger.ERROR(ClassName,e);
	     Assert.fail();
		}
	}
	/**
	 * The function inputs Ctrl along with other key from keyboard.
	 * @param command takes string value Ctrl.
	 * @param keyvalue takes string value which needs to be pressed along with Ctrl key.
	 * @throws IOException 
	 */
	public void PressKeysWithCtrl(String command, String keyvalue) throws IOException
	{
		String callerClassName = new Exception().getStackTrace()[2].getMethodName();
		String command1 = command.substring(0,1).toUpperCase() + command.substring(1).toLowerCase();
		String keyvalue1 = keyvalue.toLowerCase();
		try{
		if(command1.equalsIgnoreCase("Ctrl"))
		{
			Actions act=new Actions(b.driver);
	        act.keyDown(Keys.CONTROL).sendKeys(keyvalue1).keyUp(Keys.CONTROL).perform();
	        ReportEvents.Done(callerClassName+":WebUIElement", "Control Key is pressed successfully.",b);
	        //Logger.INFO(ClassName, "Control Key is pressed successfully.");
		}
		}
		catch(Exception e)
		{
			ReportEvents.Error(callerClassName+":WebUIElement", e,b);
	    // Logger.ERROR(ClassName,e);
	     Assert.fail();
		}
	}
	/**
	 * The function inputs various keys from keyboard specific to a web element.
	 * @param command takes string value which needs to be input from keyboard like Down, Left, Up, Right, Backspace, Alt, Ctrl, Delete, Enter and Spacebar
	 * @param times takes a integer value of number of times the command is to be executed
	 * @throws IOException 
	 */
	public void PressKeyOnElement(String command, int times) throws IOException
	{
		String callerClassName = new Exception().getStackTrace()[2].getMethodName();
		String command1 = command.substring(0,1).toUpperCase() + command.substring(1).toLowerCase();
		try{
			
		switch(command1)
		{
		case "Down":
			for(int i=1;i<=times;i++)
			{
				b.element.sendKeys(Keys.ARROW_DOWN);
			}
			ReportEvents.Done(callerClassName+":WebUIElement","Arrow Down Key is pressed successfully.",b);
			// Logger.INFO(ClassName, "Arrow Down Key is pressed successfully.");
			 break;
		case "Left":
			for(int i=1;i<=times;i++)
			{
				b.element.sendKeys(Keys.ARROW_LEFT);
			}
			ReportEvents.Done(callerClassName+":WebUIElement","Arrow Left Key is pressed successfully.",b);
			// Logger.INFO(ClassName, "Arrow Left Key is pressed successfully.");
			 break;
		case "Up":
			for(int i=1;i<=times;i++)
			{
				b.element.sendKeys(Keys.ARROW_UP);
			}
			ReportEvents.Done(callerClassName+":WebUIElement","Arrow Up Key is pressed successfully.",b);
			 //Logger.INFO(ClassName, "Arrow Up Key is pressed successfully.");
			 break;
		case "Right":
			for(int i=1;i<=times;i++)
			{
				b.element.sendKeys(Keys.ARROW_RIGHT);
				ReportEvents.Done(callerClassName+":WebUIElement","Arrow Right Key is pressed successfully.",b);
			// Logger.INFO(ClassName, "Arrow Right Key is pressed successfully.");
			}
			 break;
		case "Backspace":
			for(int i=1;i<=times;i++)
			{
				b.element.sendKeys(Keys.BACK_SPACE);	
			}
			ReportEvents.Done(callerClassName+":WebUIElement","Back space Key is pressed successfully.",b);
			// Logger.INFO(ClassName, "Back space Key is pressed successfully.");
			 break;
		case "Delete":
			for(int i=1;i<=times;i++)
			{ 
				b.element.sendKeys(Keys.DELETE);
			} 
			ReportEvents.Done(callerClassName+":WebUIElement","Delete Key is pressed successfully.",b);
			//Logger.INFO(ClassName, "Delete Key is pressed successfully.");
			 break;
		case "Enter":
			for(int i=1;i<=times;i++)
			{ 
				b.element.sendKeys(Keys.ENTER);	
			}
			ReportEvents.Done(callerClassName+":WebUIElement","Enter Key is pressed successfully.",b);
			//Logger.INFO(ClassName, "Enter Key is pressed successfully.");
			 break;
		case "Tab":
			for(int i=1;i<=times;i++)
			{ 
				b.element.sendKeys(Keys.TAB);	
			}
			ReportEvents.Done(callerClassName+":WebUIElement","Enter Key is pressed successfully.",b);
			//Logger.INFO(ClassName, "Enter Key is pressed successfully.");
			 break;
		case "Spacebar":
			for(int i=1;i<=times;i++)
			{ 
				b.element.sendKeys(Keys.SPACE);
			} 
			ReportEvents.Done(callerClassName+":WebUIElement","Space Key is pressed successfully.",b);
			//Logger.INFO(ClassName, "Space Key is pressed successfully.");
			 break;
		}	
		}
		catch(Exception e)
		{
			ReportEvents.Error(callerClassName+":WebUIElement", e,b);
	    // Logger.ERROR(ClassName,e);
	     Assert.fail();
		}
	}
	
	/**
	 * The function inputs various keys from keyboard.
	 * @param command takes string value which needs to be input from keyboard like Down, Left, Up, Right, Backspace, Alt, Ctrl, Delete, Enter and Spacebar
	 * @param times takes a integer value of number of times the command is to be executed
	 * @throws IOException 
	 */
	public void PressKey(String command, int times) throws IOException
	{
		String callerClassName = new Exception().getStackTrace()[2].getMethodName();
		String command1 = command.substring(0,1).toUpperCase() + command.substring(1).toLowerCase();
		Actions actions = new Actions(b.driver);
		try
		{			
			switch(command1)
			{
				case "Enter":
				for(int i=1;i<=times;i++)
				{
					actions.sendKeys(Keys.ENTER).build().perform();
				}
				ReportEvents.Done(callerClassName+":WebUIElement","Enter Key is pressed successfully.");
				break;
							
				case "Down":
				for(int i=1;i<=times;i++)
				{
					actions.sendKeys(Keys.DOWN).build().perform();
				}
				ReportEvents.Done(callerClassName+":WebUIElement","DownArrow Key is pressed successfully.");
				break;
				
				case "Up":
				for(int i=1;i<=times;i++)
				{
					actions.sendKeys(Keys.UP).build().perform();
				}
				ReportEvents.Done(callerClassName+":WebUIElement","UpArrow Key is pressed successfully.");
				break;		
				
				case "Left":
				for(int i=1;i<=times;i++)
				{
					actions.sendKeys(Keys.LEFT).build().perform();
				}
				ReportEvents.Done(callerClassName+":WebUIElement","UpArrow Key is pressed successfully.");
				break;	
				
				case "Right":
				for(int i=1;i<=times;i++)
				{
					actions.sendKeys(Keys.RIGHT).build().perform();
				}
				ReportEvents.Done(callerClassName+":WebUIElement","UpArrow Key is pressed successfully.");
				break;	
					
				case "Backspace":
				for(int i=1;i<=times;i++)
				{
					actions.sendKeys(Keys.BACK_SPACE).build().perform();
				}
				ReportEvents.Done(callerClassName+":WebUIElement","Backspace Key is pressed successfully.");
				break;
						
				case "Spacebar":
				for(int i=1;i<=times;i++)
				{
					actions.sendKeys(Keys.SPACE).build().perform();
				}
				ReportEvents.Done(callerClassName+":WebUIElement","Spacebar Key is pressed successfully.");
				break;
				
				case "Tab":
				for(int i=1;i<=times;i++)
				{
					actions.sendKeys(Keys.TAB).build().perform();
				}
				ReportEvents.Done(callerClassName+":WebUIElement","Spacebar Key is pressed successfully.");
				break;
				
				
				default: 
					ReportEvents.Fatal(callerClassName+":WebUIElement", "Invalid key name.");		
					}	
			
		}
		catch(Exception e)
		{
			ReportEvents.Error(callerClassName+":WebUIElement", e);
		     Assert.fail();
		}
	}
	
	/**
	 * The function scrolls till the particular web element.
	 * @throws IOException 
	 */
	public void ScrollTillElement() throws IOException
	{
		String callerClassName = new Exception().getStackTrace()[1].getMethodName();
		try{
			
			((JavascriptExecutor) b.driver).executeScript(
		            "arguments[0].scrollIntoView();", b.element);
		ReportEvents.Done(callerClassName+":WebUIElement", "Element: "+b.element+ "is reached.",b);
		}
		catch(Exception e)
		{
		 ReportEvents.Error(callerClassName+":WebUIElement",e);
	     Assert.fail();
		}
	}

}
