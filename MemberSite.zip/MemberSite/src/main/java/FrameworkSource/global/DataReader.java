package FrameworkSource.global;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Arrays;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.junit.Assert;

import FrameworkSource.global.reporter.*;
/**
 * DataReader class consists of all the functions related to external data sheet i.e Data.xlsx.
 */
public class DataReader {
	
	String clName = "";
	String Testname, Browser, Environment, WebApp;
	int StartRow, EndRow; 
	String DataTable = System.getProperty("user.dir") + "\\src\\test\\java\\Data\\Data.xlsx";
	int present = 0;	
	/**
	* The constructor retrieves different values of columns corresponding to specified data sheet.
	* @param className takes the name of data sheet inside Data.xlsx workbook.
	 * @throws IOException 
	 * @throws InvalidFormatException 
	 * @throws EncryptedDocumentException 
	*/
	public DataReader(String className) throws EncryptedDocumentException, InvalidFormatException, IOException  
	{
		String ClassName = new Exception().getStackTrace()[1].getClassName();
		File file = new File(DataTable);
		
		this.clName = className;

		FileInputStream inputStream = new FileInputStream(file);
	    Workbook workbook = null;
	    workbook = WorkbookFactory.create(inputStream);
	    Sheet sheet = workbook.getSheet("Environment");
	    DataFormatter formatter = new DataFormatter();
  
	    int rowCount = sheet.getLastRowNum()-sheet.getFirstRowNum();
	    
	    for (int i = 1; i < rowCount+1; i++) {

	           Row row = sheet.getRow(i);
	           String firstRow = formatter.formatCellValue(row.getCell(0));
	        
	     if(firstRow.equalsIgnoreCase(className))
	     {
                Testname = firstRow;
	        	StartRow = Integer.parseInt(formatter.formatCellValue(row.getCell(1)));
	        	EndRow = Integer.parseInt(formatter.formatCellValue(row.getCell(2)));
	        	Browser = formatter.formatCellValue(row.getCell(3));
	        	Environment = formatter.formatCellValue(row.getCell(4));
	        	WebApp = formatter.formatCellValue(row.getCell(5));
	        	present = 1;
	        	break;
	        }
	        
	    }//End of for
	    
	    if(present==0)
	    {
	    	System.out.println("ERROR: DataSheet name not found in Data.xlsx");
	    	//ReportEvents.Done("PreRequisites: DataReader", "Check the name of DataSheet inside Data.xlsx");
	    	ReportEvents.Fatal(ClassName+":PreRequisites:DataReader", className+" sheet name not found in Data.xlsx");
			Assert.fail();
	    	
	    	//Logger.INFO("DataReader", "Check the name of DataSheet inside Data.xlsx");
	    }
}//End of Constructor 
	
	/**
	* The constructor retrieves different values of columns corresponding to specified data sheet.
	* @param className takes the name of data sheet inside Data.xlsx workbook.
	 * @throws IOException 
	 * @throws InvalidFormatException 
	 * @throws EncryptedDocumentException 
	*/
	public DataReader(String excelName,String className) throws EncryptedDocumentException, InvalidFormatException, IOException  
	{
		String ClassName = new Exception().getStackTrace()[1].getClassName();
		
		
		if(excelName.equals("") || excelName.equals(" "))
			this.DataTable = System.getProperty("user.dir") + "\\src\\test\\java\\Data\\Data.xlsx";
		
		else if(!excelName.contains(".xlsx"))
			this.DataTable = System.getProperty("user.dir") + "\\src\\test\\java\\Data\\"+excelName+".xlsx";	
		
		else if(excelName.contains(".xlsx"))
			this.DataTable = System.getProperty("user.dir") + "\\src\\test\\java\\Data\\"+excelName;
		
				
		else 
		{
			System.out.println("Invalid data sheet name");
			Assert.fail();
		}
		
		File file = new File(DataTable);
		
		this.clName = className;

		FileInputStream inputStream = new FileInputStream(file);
	    Workbook workbook = null;
	    workbook = WorkbookFactory.create(inputStream);
	    Sheet sheet = workbook.getSheet("Environment");
	    DataFormatter formatter = new DataFormatter();
  
	    int rowCount = sheet.getLastRowNum()-sheet.getFirstRowNum();
	    
	    for (int i = 1; i < rowCount+1; i++) {

	           Row row = sheet.getRow(i);
	           String firstRow = formatter.formatCellValue(row.getCell(0));
	        
	     if(firstRow.equalsIgnoreCase(className))
	     {
                Testname = firstRow;
	        	StartRow = Integer.parseInt(formatter.formatCellValue(row.getCell(1)));
	        	EndRow = Integer.parseInt(formatter.formatCellValue(row.getCell(2)));
	        	Browser = formatter.formatCellValue(row.getCell(3));
	        	Environment = formatter.formatCellValue(row.getCell(4));
	        	WebApp = formatter.formatCellValue(row.getCell(5));
	        	present = 1;
	        	break;
	        }
	        
	    }//End of for
	    
	    if(present==0)
	    {
	    	System.out.println("ERROR: DataSheet name not found in Data.xlsx");
	    	//ReportEvents.Done("PreRequisites: DataReader", "Check the name of DataSheet inside Data.xlsx");
	    	ReportEvents.Fatal(ClassName+":PreRequisites:DataReader", className+" sheet name not found in Data.xlsx");
			Assert.fail();
	    	
	    	//Logger.INFO("DataReader", "Check the name of DataSheet inside Data.xlsx");
	    }
}//End of Constructor 


	
	/**
	* The function returns the number of times the test case will get executed based on different data present in worksheet.
	* @return int type
	*/
	public int noOfTimes()
	{
		int times = (EndRow-StartRow)+1;
		return times;
	}
	
	/**
	* The function returns the number of browsers specified inside Browsers column of Environment sheet
	* @return int type
	*/
	public int noOfBrowsers()
	{
		String[] no = browser();
		return no.length;
	}
	
	/**
	* The function returns the browser list as string array
	* @return String array type
	*/
	public String[] browser()
	{
		String[] times = Browser.split(",");
		return times;
	}
	
	/**
	* The function returns the URL corresponding to specified test case.
	* @return String type
	*/
	public String getURL() throws Exception
	{
        File file = new File(DataTable);
		FileInputStream inputStream = new FileInputStream(file);
	    Workbook workbook = null;
	    workbook = WorkbookFactory.create(inputStream);
	    Sheet sheet = workbook.getSheet("MasterURLSheet");
	    DataFormatter formatter = new DataFormatter();
	    int sit_stage;
	    String URL="";
  
	    int rowCount = sheet.getLastRowNum()-sheet.getFirstRowNum();
	    
        if(Environment.equalsIgnoreCase("SIT"))
        {
        	sit_stage = 1; //For SIT
        }
        else{
        	sit_stage = 2; //For STAGE
        }

	    
	    for (int i = 1; i < rowCount+1; i++) {

	           Row row = sheet.getRow(i);
	           String firstRow = formatter.formatCellValue(row.getCell(0));
	        
	     if(firstRow.equalsIgnoreCase(WebApp))
	     {
	    	 //Go to particular cell 1 or 2 and just fetch value
	            URL = formatter.formatCellValue(row.getCell(sit_stage));

	    	 break;
	     }
	    }
		return URL;
	}
	
	/**
	* The function returns a 2-D array from data sheet
	* @throws IOException 
	* @throws InvalidFormatException 
	* @throws EncryptedDocumentException 
	* @return String 2-D array type
	*/
	public String[][] getData() throws EncryptedDocumentException, InvalidFormatException, IOException 
	{
		String ClassName = new Exception().getStackTrace()[1].getClassName();
		int newStart = StartRow+1;
		//System.out.println(newStart);
		int newEnd = EndRow+1;
		//System.out.println(newEnd);
		int row = (newEnd - newStart)+1;
		//System.out.println(row);
        int arrCount = 0;
        String sheetpresent="";
        String returnValues[][]=null;
        File file = new File(DataTable);
        FileInputStream inputStream = new FileInputStream(file);
        Workbook workbook = null;
        workbook = WorkbookFactory.create(inputStream);
        Sheet sheet = workbook.getSheet(clName);
        
			if (sheet == null)
			{ //If sheet don't exists it can happen there is no data at all
				ReportEvents.Done(ClassName+":"+"PreRequisites:DataReader", "WARNING: Sheet name "+ clName+" not found");	
				sheetpresent="false";
			}

    		
    		DataFormatter formatter = new DataFormatter();
    		Row row3 = null;

    	
	    if(sheetpresent.equals("false"))
	    {
	    	//ReportEvents.Done(ClassName+":"+"PreRequisites:DataReader","Data from sheet "+clName+" cannot be found.");
	    	//Logger.INFO("DataReader", "Data from sheet "+clName+" cannot be found.");	
	    }
	    
	    else if(sheet.getRow(0)==null || sheet.getRow(1)==null )
	    {
	    	ReportEvents.Done(ClassName+":"+"PreRequisites:DataReader","Navigated to sheet name : "+ clName);
	    	ReportEvents.Done(ClassName+":"+"PreRequisites:DataReader",clName+" sheet is blank.");
			//Logger.INFO("DataReader", "Navigated to sheet name : "+ clName);	
			//Logger.INFO("DataReader", clName+" sheet is blank.");	
	    }
	    
	    else
	    {	//String callerClassName = new Exception().getStackTrace()[1].getClassName();
	    	ReportEvents.Done(ClassName+":"+"PreRequisites:DataReader","Navigated to sheet name : "+ clName);
			//Logger.INFO(callerClassName+"DataReader", "Navigated to sheet name : "+ clName);	
	    	row3 = sheet.getRow(0);
	    	String[][] values=new String[row][row3.getLastCellNum()]; //2D array to store elements
	    	returnValues = new String[row][row3.getLastCellNum()];
		    for(int j = StartRow; j <= EndRow; j++) {
		    	int colCount;
		    Row row2 = sheet.getRow(j);
		    
		    //to handle empty row or cell with no data to check required fields
		    if (row2 == null)
		    {
		    	colCount = row3.getLastCellNum();
		    }
		    else if(row2.getLastCellNum()<row3.getLastCellNum())
		    {
		    	colCount = row3.getLastCellNum();
		    }
		    else
		    	colCount =  row2.getLastCellNum();
		   
		    //String firstRow = formatter.formatCellValue(row2.getCell(0));
			for(int k = 0; k < colCount; k++) 
		    {	//to handle empty row or cell
				 if (row2 == null)
				    {
				    	values[arrCount][k]= "";
				    }
				else
			    values[arrCount][k] = formatter.formatCellValue(row2.getCell(k));
		    }
			      arrCount=arrCount+1;

			}
			arrCount = 0;
			for(int i=0; i<values.length; i++)
				  for(int j=0; j<values[i].length; j++)
					  returnValues[i][j]=values[i][j];
	    }
	   
	    inputStream.close();
	    workbook.close();
		return returnValues;
		
	}	

	/**
	* The function retrieves a row from 2-D array and stores it in 1-D array 
	* @return String 1-D array type
	 * @throws IOException 
	*/
	public String[] SingleArr(String userData[][],int index) throws IOException
	{
		String ClassName = new Exception().getStackTrace()[1].getClassName();
		String singleData[]=null;
		if(userData==null)
		{
			ReportEvents.Done(ClassName+":"+"PreRequisites:DataReader","Data returned is empty");
			//Logger.INFO("DataReader", "Data returned is empty");
		}
		
		else
		{
		int col = userData[0].length; //No. of columns in userData
		//System.out.println(col);
		String currentData[] = new String[col];
		
		for(int i=0;i<col;i++)
		{
			currentData[i]=userData[index][i];
			//System.out.println(currentData[i]);
		}
		
		singleData = Arrays.copyOf(currentData, currentData.length);
		ReportEvents.Done(ClassName+":"+"PreRequisites:DataReader","Current data is returned as array");
		//Logger.INFO("DataReader", "Current data is returned as array");	
		}
		return singleData;
	}
	
	
}
	
	

