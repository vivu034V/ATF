package FrameworkSource.global.reporter;

import java.io.File;
import java.io.IOException;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import FrameworkSource.web.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
/**
 * ReportsEvents class consists of functions dealing with configuration related to screenshots and customized data in reports
 */
public class ReportEvents {
	public static Browser b;
	public static String Flag= "False";
	public static String Flag1= "False";
	public static List<String> Trace =new ArrayList<String>();
	/**
	* The constructor initializes Browser class object
	*/
	public ReportEvents(Browser browser)
	{
		b = browser;
	}

	public static void CaptureScreenShots(String flag,String flag1)
	{
		String CallerMethod=new Exception().getStackTrace()[1].getMethodName();
		Trace.add(CallerMethod);
		if(Trace.get(0).toString().equalsIgnoreCase("test"))
		{
			if(Trace.get(Trace.size()-1).toString().equalsIgnoreCase("test"))
			{
				Flag=flag;
				if(flag.equalsIgnoreCase("True"))
				{
					Flag1=flag1;
				}
			}
			
		}
		else if(Trace.get(0).toString().equalsIgnoreCase("<init>"))
		{
			Flag=flag;
			if(flag.equalsIgnoreCase("True"))
			{
				Flag1=flag1;
			}
		}
		
	}

	public static void CaptureScreenShots(String flag)
	{
		String CallerMethod=new Exception().getStackTrace()[1].getMethodName();
		Trace.add(CallerMethod);
		if(Trace.get(0).toString().equalsIgnoreCase("test"))
		{
			if(Trace.get(Trace.size()-1).toString().equalsIgnoreCase("test"))
			{
				Flag=flag;
				
			}
			
		}
		else if(Trace.get(0).toString().equalsIgnoreCase("<init>"))
		{
			Flag=flag;
			
		}
		
	}
	
	public static void Done(String StepName, String StepDescription) throws IOException
	{
		Logger.INFO(StepName, StepDescription);
		
	}
	public static void Error(String StepName, Exception e) throws IOException
	{
		Logger.ERROR(StepName, e);
		
	}
	public static void Fatal(String StepName, String StepDescription) throws IOException
	{
		Logger.FATAL(StepName, StepDescription);
		
	}
	public static void Done(String StepName, String StepDescription, Browser browser) throws IOException
	{
		Logger.INFO(StepName, StepDescription);
		if(Flag1.equalsIgnoreCase("True"))
		{
			TakeScreenshot(browser, StepName);
		}
		
	}
	public static void Error(String StepName, Exception e, Browser browser) throws IOException
	{
		Logger.ERROR(StepName, e);
		if(Flag1.equalsIgnoreCase("True"))
		{
			TakeScreenshot(browser, StepName);
		}
		
	}
	public static void Fatal(String StepName, String StepDescription, Browser browser) throws IOException
	{
		Logger.FATAL(StepName, StepDescription);
		if(Flag1.equalsIgnoreCase("True"))
		{
			TakeScreenshot(browser, StepName);
		}
		
	}
	/**
	* The method writes data to logs based on status(Pass/Fail)
	* @param it takes different string values like status, stepname and stepdescription
	* @throws IOException 
	*/
	public static void Reporter(String status, String stepname, String stepdescription) throws IOException
	{
		if(stepname.contains(" "))
		{
			stepname=stepname.replaceAll(" ", "_");
		}
		if(status.equalsIgnoreCase("Pass"))
		{
		WritePassToLogger(stepname,stepdescription);
		}
		else if(status.equalsIgnoreCase("Fail"))
		{
			WriteFailToLogger(stepname,stepdescription);
		}
	if(Flag.equalsIgnoreCase("True"))
	{
		TakeScreenshot1(b, stepname);
	}
	}
	
	private static void TakeScreenshot1(Browser b2, String stepname) throws IOException {
		// TODO Auto-generated method stub
		String callerClassName = stepname;
		String ClassName= new Exception().getStackTrace()[3].getClassName();
		String LineNum = String.valueOf(new Exception().getStackTrace()[3].getLineNumber());
		String class1="";
		String class2="";
		if(callerClassName.equals("driver"))
		{
			callerClassName=stepname;
		}
		long count=ClassName.chars().filter(ch->ch=='.').count();
		if(count==1)
		{
			 class1 = ClassName.split("\\.")[1];
			 class2 = class1.split("\\$")[0];
		}
		if(count==2)
		{
			 class1 = ClassName.split("\\.")[2];
			 class2 = class1.split("\\$")[0];
		}
		Date date = new Date();
		String datestring = date.toString();
		datestring = datestring.replaceAll(":", "");
		String class3 = datestring.split(" ")[3];
		String projectPath = System.getProperty("user.dir");
		File src= ((TakesScreenshot)b2.driver).getScreenshotAs(OutputType.FILE);
		String ImageLocation = projectPath+"//ExecutionReports//"+class2+"//"+callerClassName+"//"+LineNum+"//"+class3+".png";
		ImageLocation =ImageLocation.replaceAll(" ", "%20");
		FileUtils.copyFile(src, new File(ImageLocation));
		Logger.INFO(callerClassName+":ScreenShots", "Screen Shot taken and saved under path: "+ImageLocation);	
	}

	/**
	* The method takes screenshot and saves it to testcase folder with screenshot name as stepname  
	* @param Browser expects the Browser class object and stepname accepts the String value
	* @throws IOException 
	*/
	private static void TakeScreenshot(Browser b1, String stepname) throws IOException
	{
		
		String callerClassName = new Exception().getStackTrace()[3].getMethodName();
		String ClassName= new Exception().getStackTrace()[3].getClassName();
		String LineNum = String.valueOf(new Exception().getStackTrace()[3].getLineNumber());
		String class1="";
		String class2="";
		if(callerClassName.equals("driver"))
		{
			callerClassName=new Exception().getStackTrace()[2].getMethodName();
		}
		long count=ClassName.chars().filter(ch->ch=='.').count();
		
		 class1 = ClassName.split("\\.")[(int) count];
		 class2 = class1.split("\\$")[0];
	
		Date date = new Date();
		String datestring = date.toString();
		datestring = datestring.replaceAll(":", "");
		String class3 = datestring.split(" ")[3];
		String projectPath = System.getProperty("user.dir");
		File src= ((TakesScreenshot)b1.driver).getScreenshotAs(OutputType.FILE);
		String ImageLocation = projectPath+"//ExecutionReports//"+class2+"//"+callerClassName+"//"+LineNum+"//"+class3+".png";
		ImageLocation =ImageLocation.replaceAll(" ", "%20");
		FileUtils.copyFile(src, new File(ImageLocation));
		Logger.INFO(callerClassName+":ScreenShots", "Screen Shot taken and saved under path: "+ImageLocation);
		
	}
	/**
	 * The function writes FATAL logs in logger files.
	 * @param stepname takes the name which needs to be logged in Log4J.
	 * @param stepdescription takes the description of the logs which needs to be logged in Log4J.
	 */
	private static void WriteFailToLogger(String stepname, String stepdescription) 
	{
	Logger.FATAL(stepname, stepdescription);	
		
	}
	/**
	 * The function writes INFO logs in logger files.
	 * @param stepname takes the name which needs to be logged in Log4J.
	 * @param stepdescription takes the description of the logs which needs to be logged in Log4J.
	 */
	private static void WritePassToLogger(String stepname, String stepdescription) {
		Logger.INFO(stepname, stepdescription);	
		
	}

	
}
