package FrameworkSource.global;

import FrameworkSource.global.reporter.*;
import FrameworkSource.web.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.Assert;
/**
 * ORReader class consists of all the functions related to OR(Object Repository) i.e Properties.xlsx.
 */
public class ORReader {
	
	Browser b;
	String ORSheet = System.getProperty("user.dir")+"\\src\\test\\java\\OR\\Properties.xlsx";
	
	public ORReader(Browser b)
	{
		this.b = b;
	}
	
	/**
	* The function retrieves the entire sheet i.e Proprties.xlsx as 2-D string array based on Page value
	* @throws IOException 
	* @return String 2-D array type
	*/
	public String[][] Properties(String page) throws IOException 
	{
		int flag= 0;
		File file = new File(ORSheet);
	    FileInputStream inputStream = new FileInputStream(file);
	    Workbook workbook = null;
	    String[][] AllValues = null;
	   // String fileExtensionName = fileName.substring(fileName.indexOf("."));
	    workbook = new XSSFWorkbook(inputStream);
        List<String> sheetNames = new ArrayList<String>();
        for (int i=0; i<workbook.getNumberOfSheets(); i++) {
            sheetNames.add( workbook.getSheetName(i) );
        }
        
        for(String sheet_name: sheetNames)
        {
               if(sheet_name.equalsIgnoreCase(page))
               {
                   flag = 1;
                   Sheet sheet = workbook.getSheet(page);
                b.rowCount = sheet.getLastRowNum()-sheet.getFirstRowNum();
                b.columnCount = sheet.getRow(0).getLastCellNum();
                //int index = 0;
                AllValues = new String[b.rowCount +1][b.columnCount];
                //String[] FoundValue = new String[Browsers.columnCount-1];
                for (int i = 0; i < b.rowCount +1; i++) 
                {
                Row row = sheet.getRow(i);
                    for (int j = 0; j < row.getLastCellNum(); j++) 
                    {
                          AllValues[i][j] =row.getCell(j).getStringCellValue();
                    }
                }

				    break;
			       }
               
               else
               {
            	   flag=0;
               }
        }
        
        if(flag==0)
        {
        	workbook.close();
            ReportEvents.Fatal("ORReader", " Property sheetname passed i.e. : "+ page+ ": is not present in Property.xlsx");
			//ReportGenerator.Generate("true");
			Assert.fail();
        }
	    workbook.close();//Newly added
	    
		return AllValues;
	}
	
	/**
	* The function retrieves the entire sheet i.e Proprties.xlsx as 2-D string array based on Page value
	* @throws IOException 
	* @return String 2-D array type
	*/
	public String[][] Properties(String orSheet,String page) throws IOException 
	{
		
		if(orSheet.equals("") || orSheet.equals(" "))
			this.ORSheet = System.getProperty("user.dir")+"\\src\\test\\java\\OR\\Properties.xlsx";
		
		else if(!orSheet.contains(".xlsx"))
			this.ORSheet = System.getProperty("user.dir") + "\\src\\test\\java\\OR\\"+orSheet+".xlsx";	
		
		else if(orSheet.contains(".xlsx"))
			this.ORSheet = System.getProperty("user.dir") + "\\src\\test\\java\\OR\\"+orSheet;
		
				
		else 
		{
			System.out.println("Invalid OR sheet name");
			Assert.fail();
		}
				
		int flag= 0;

		File file =    new File(ORSheet);
	    FileInputStream inputStream = new FileInputStream(file);
	    Workbook workbook = null;
	    String[][] AllValues = null;
	   // String fileExtensionName = fileName.substring(fileName.indexOf("."));
	    workbook = new XSSFWorkbook(inputStream);
        List<String> sheetNames = new ArrayList<String>();
        for (int i=0; i<workbook.getNumberOfSheets(); i++) {
            sheetNames.add( workbook.getSheetName(i) );
        }
        
        for(String sheet_name: sheetNames)
        {
               if(sheet_name.equalsIgnoreCase(page))
               {
                   flag = 1;
                   Sheet sheet = workbook.getSheet(page);
                b.rowCount = sheet.getLastRowNum()-sheet.getFirstRowNum();
                b.columnCount = sheet.getRow(0).getLastCellNum();
                //int index = 0;
                AllValues = new String[b.rowCount +1][b.columnCount];
                //String[] FoundValue = new String[Browsers.columnCount-1];
                for (int i = 0; i < b.rowCount +1; i++) 
                {
                Row row = sheet.getRow(i);
                    for (int j = 0; j < row.getLastCellNum(); j++) 
                    {
                          AllValues[i][j] =row.getCell(j).getStringCellValue();
                    }
                }

				    break;
			       }
               
               else
               {
            	   flag=0;
               }
        }
        
        if(flag==0)
        {
        	workbook.close();
            ReportEvents.Fatal("ORReader", " Property sheetname passed i.e. : "+ page+ ": is not present in Property.xlsx");
			//ReportGenerator.Generate("true");
			Assert.fail();
        }
	    workbook.close();//Newly added
	    
		return AllValues;
	}

	
	/**
	* The function retrieves a value based on logical name of web element
	* @return String 1-D array type
	 * @throws IOException 
	*/
	public String[] FindExactvalue(String Value) throws IOException
	{
		String ClassName= new Exception().getStackTrace()[4].getClassName();
		String callerClassName = new Exception().getStackTrace()[4].getMethodName();
		int index = 0;
		String[] FoundValue = new String[b.columnCount-2];
		try
		{
		for (int i = 0; i < b.rowCount+1; i++) 
	    {
	      if(b.PageValues[i][0].equals(Value))
	            {
	    	  		index =i;
	            }
	        }

		if(index==0)
		{
			//ReportEvents.Done(ClassName+": "+callerClassName, " Property values for: "+ Value+ ": is not present ");
			//Logger.INFO(ClassName, " Property values for: "+ Value+ ": is not present ");
		}
		
		else
		{     		
	    if(ClassName.contains("_FR")||ClassName.contains("_fr")||ClassName.contains("_Fr")||ClassName.contains("_fR")) //French
	    	{
	    	FoundValue[0] = b.PageValues[index][1];
	    //	ReportEvents.Done(ClassName+": "+callerClassName, " Property values for: "+ Value+ ": "+b.PageValues[index][1]);
	    	//Logger.INFO(ClassName, " Property values for: "+ Value+ ": "+b.PageValues[index][1]);
	    	FoundValue[1] = b.PageValues[index][3]; 
	    //	ReportEvents.Done(ClassName+": "+callerClassName," Property values for: "+ Value+ ": "+b.PageValues[index][3]);
	    	//Logger.INFO(ClassName, " Property values for: "+ Value+ ": "+b.PageValues[index][3]);
    	   	}
	    	else //English
	    	{
	    		FoundValue[0] = b.PageValues[index][1];
	    	//	ReportEvents.Done(ClassName+": "+callerClassName, " Property values for: "+ Value+ ": "+b.PageValues[index][1]);
	    		//Logger.INFO(ClassName, " Property values for: "+ Value+ ": "+b.PageValues[index][1]);
		    	FoundValue[1] = b.PageValues[index][2]; 
		    //	ReportEvents.Done(ClassName+": "+callerClassName,  " Property values for: "+ Value+ ": "+b.PageValues[index][2]);
	    		//Logger.INFO(ClassName, " Property values for: "+ Value+ ": "+b.PageValues[index][2]);
	    	}
	    
	    }	//End of else
		
	}//End of try
		
		catch( Exception e)
		{
			ReportEvents.Error(ClassName+":"+callerClassName, e);
			//Logger.INFO(ClassName, "Element Not Present");
		}
		return FoundValue;
		
	}
	
	/**
	* The function checks whether the values are present in Properties sheet.
	* @param value takes a string value.
	* @return boolean
	 * @throws IOException 
	*/
	public boolean FindProperty(String Value) throws IOException
	{
		String ClassName= new Exception().getStackTrace()[4].getClassName();
		boolean flag = false;
		try
		{
		for (int i = 0; i < b.rowCount+1; i++) 
	    {
	      if(b.PageValues[i][0].equals(Value))
	            {
	    	  		flag=true;	    	  		
	            }
	    }
		}
		catch(Exception e)
		{
			ReportEvents.Fatal(ClassName, " Property values for: "+Value+ ": is not present ");
			Assert.fail();
			//Logger.INFO("ORReader", " Property values for: "+Value+ ": is not present ");
			
		}
		
		return flag;
		
	}
}
