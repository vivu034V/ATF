package FrameworkSource;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class Modify 
{
	static void modifyFile(String filePath) throws EncryptedDocumentException, InvalidFormatException
    {
		try
        {
		String excelname=null; //Name of excel sheet which test case is referring to
		List<String> headerexcel = new ArrayList<String>(); //It stores the header values of related test sheet
		List<String> headertest = new ArrayList<String>(); //It stores the count of test data used in existing scripts
        File file = new File(filePath); //Path of testscript
        BufferedReader reader = new BufferedReader(new FileReader(file));
        String line = "", oldtext = "";
        while((line = reader.readLine()) != null)
            {
           	if(line.contains("new DataReader"))
        	{
        		excelname=between(line,"\"","\""); //Reading the excel sheet name
        	}
           	
           	else if(line.contains("userData["))
           	{	
           		
           		if(headertest.contains(between(line,"userData[","]"))==false && between(line,"userData[","]")!="") //If that string is not added in List previously
           		{
           			headertest.add(between(line,"userData[","]")); //Adding values like 0, 1 etc.
           		}

           	}
           	
           	else if(line.contains("new Page"))
        	{
        		line = line + "\n\t" + "HashMap<String, String> testdata, commondata;"; //Adding HashMap variables
        	}
           	
           	else if(line.contains("SingleArr"))
        	{
        		line = "\t\t"+"testdata = datareader.getTestData(i);"; //Updating SingleArr statement
        	}
           	
           	else if(line.contains("ScreenShotRequired"))
           	{
           		//Updating ScreenShotRequired instance
           		if(between(line,"ScreenShotRequired(\"","\"").equals("true"))
           		{
           			//System.out.println("true1");
            		line = "\t\t"+"ReportEvents.CaptureScreenShots(\"true\",\"false\");";
           		}
           		
           		else if(between(line,"ScreenShotRequired(\"","\"").equals("false"))
           		{
            		line = "\t\t"+"ReportEvents.CaptureScreenShots(\"false\",\"false\");";
           		}
           		
           	}
           	
           	
            oldtext += line + "\r\n";
            }
        reader.close();
       
        //1)Adding hashmap import
        String newtext = oldtext.replaceAll("import org.junit.*;", "import org.junit.*;\r\n" + 
        		"import java.util.HashMap;");

        //2)Replacing previous 2-D test array instance
        String newtext2 = newtext.replaceAll("String\\[]\\[] TestcaseData = datareader.getData\\(\\);", "commondata = datareader.getCommomData\\();");
        
        //3)Removing userData instance in method parameter
        String newtext3 = newtext2.replaceAll("String userData\\[]", "");
        
        //4)Removing currentData instance
        String newtext4 = newtext3.replaceAll("currentData", "");
        
        if(headertest.isEmpty()) {
        //	System.out.println("No use of userdata");
        }
        else {
        //System.out.println(excelname);
    	String DataTable = System.getProperty("user.dir") + "\\src\\test\\java\\Data\\Data.xlsx";
		File file1 = new File(DataTable);
	    DataFormatter formatter = new DataFormatter();
		FileInputStream inputStream = new FileInputStream(file1);
	    Workbook workbook = null;
	    workbook = WorkbookFactory.create(inputStream);
	    Sheet sheet = workbook.getSheet(excelname);
	    
	    Row row = sheet.getRow(0);
	    int i = sheet.getRow(0).getPhysicalNumberOfCells();
	    System.out.println("callCount"+i);
	    
	    for(int j=0;j<i;j++)
	    {
	    	headerexcel.add(formatter.formatCellValue(row.getCell(j)));
	    }
	    
	      for(int v=0;v<headertest.size();v++)
	      {
	          newtext4 = newtext4.replaceAll("userData\\["+headertest.get(v)+"\\]", "testdata.get(\""+headerexcel.get(v)+"\")"); 
	      }
        }
        
        FileWriter writer = new FileWriter(file);
       
            writer.write(newtext4);writer.close();
    }
    catch (IOException ioe)
        {
        ioe.printStackTrace();
    }    }

	static String between(String value, String a, String b) {
	     
        int posA = value.indexOf(a);
        if (posA == -1) {
            return "";
        }
        int posB = value.lastIndexOf(b);
        if (posB == -1) {
            return "";
        }
        int adjustedPosA = posA + a.length();
        if (adjustedPosA >= posB) {
            return "";
        }
        return value.substring(adjustedPosA, posB);
    
}
	
	private static void findClasses() throws ClassNotFoundException, EncryptedDocumentException, InvalidFormatException 
	{
		File global = new File(System.getProperty("user.dir")+"\\src\\test\\java\\Tests");
		File[] curFiles = global.listFiles(); 
		File[] innerdirfiles , newarr = null;
		List<File> file = new ArrayList<File>();
		
		 for(int i =0;i<curFiles.length;i++)
		 { 
			 
		 if(curFiles[i].isDirectory())
		 {
			 String folder_name = curFiles[i].getName();
			 File innerdir = new File(System.getProperty("user.dir")+"\\src\\test\\java\\Tests\\"+folder_name);
			  innerdirfiles = innerdir.listFiles();
			  
			 // newarr = innerdirfiles.clone();
				
				 for(int j =0;j<innerdirfiles.length;j++)
				 { 
					 
			  file.add(innerdirfiles[j]);
			  
				 }
			 
		 }
		 else {
			  file.add(curFiles[i]);

		 }

		 }
		 for( File c : file )
		 {
			 System.out.println(c.getAbsolutePath());
			 modifyFile(c.getAbsolutePath());
		 }
		 
		
    }

	public static void main(String[] args) throws ClassNotFoundException, EncryptedDocumentException, InvalidFormatException
	{		
		findClasses();
	}

}

